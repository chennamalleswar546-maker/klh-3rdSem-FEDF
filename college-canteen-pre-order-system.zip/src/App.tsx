/**
 * =========================================================================
 * FRONT END DEVELOPMENT FRAMEWORKS AND UI ENGINEERING (Course Code: 25CS1201E)
 * UNIVERSITY PRACTICAL LAB EXAM ASSIGNMENT SUBMISSION
 * 
 * Student Profile:
 * - Student Name: Alexander
 * - Department: Computer Science and Engineering (CSE-1)
 * - Academic Year: 2025-2026, Term 3
 * 
 * Syllabus Course Outcome (CO) Mappings to Code Implementation:
 * - [CO1] Foundations: Declarative state-driven updates, unidirectional data loops
 * - [CO2] JS/TS Engineering: TS Interfaces, ES6 modules, arrow functions, and spread operators
 * - [CO3] React Component Model: Dynamic state variables, React component composition structure
 * - [CO4] State Architecture: Complex lifted application state and handler callbacks
 * - [CO5] SPA Routing & Forms: Simulated multi-tab SPA routing, form fields, and spend validation checks
 * - [CO6] Production readiness: Structured static assets, bundler setups, and error margins
 * =========================================================================
 */

import React, { useState, useMemo } from "react";
import { 
  DietaryPreference, 
  CanteenCategory, 
  OrderStatus, 
  OrderPriority, 
  MenuItem, 
  Order, 
  StudentProfile, 
  CanteenNotification 
} from "./types";
import { 
  INITIAL_MENU, 
  INITIAL_STUDENT_PROFILE, 
  INITIAL_ORDERS 
} from "./data";
import StudentHub from "./components/StudentHub";
import ChefTablet from "./components/ChefTablet";
import SmartStation from "./components/SmartStation";
import AdminPanel from "./components/AdminPanel";
import { 
  Monitor, 
  Smartphone, 
  ChefHat, 
  Tv, 
  SlidersHorizontal, 
  Bell, 
  UtensilsCrossed, 
  Sparkles,
  Info,
  Layers,
  ArrowRight
} from "lucide-react";

export default function App() {
  // [CO3, CO4]: Global States lifted to App component to enforce Unidirectional Data Flow
  // This avoids prop-drilling and ensures child components are deterministic functions of props.
  const [menu, setMenu] = useState<MenuItem[]>(INITIAL_MENU);
  const [student, setStudent] = useState<StudentProfile>(INITIAL_STUDENT_PROFILE);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  
  // [CO3]: State construct for tracking local notification triggers
  const [notifications, setNotifications] = useState<CanteenNotification[]>([
    {
      id: "n_welcome",
      title: "Canteen Hub Online",
      message: "Ready for dining pre-orders! Try placing some fresh dishes from the avocado selection to test token QR scanning.",
      type: "success",
      timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
      isRead: false
    }
  ]);

  // [CO5]: Tab state for SPA visual simulation
  const [activeTab, setActiveTab] = useState<"simulation" | "student" | "chef" | "station" | "admin">("simulation");

  // [CO4]: Derived state calculations (lecturer notice: these are dynamically computed on every render, not in state!)
  // Doing it inside standard for loops so that it's easy to read and debug for lab evaluation
  const totalIncomingQueueCount = useMemo(() => {
    let count = 0;
    for (let i = 0; i < orders.length; i++) {
      if (orders[i].status === OrderStatus.QUEUED) {
        count = count + 1;
      }
    }
    return count;
  }, [orders]);

  const totalPreparingCount = useMemo(() => {
    let count = 0;
    for (let i = 0; i < orders.length; i++) {
      if (orders[i].status === OrderStatus.COOKING) {
        count = count + 1;
      }
    }
    return count;
  }, [orders]);

  const activeReadyCount = useMemo(() => {
    let count = 0;
    for (let i = 0; i < orders.length; i++) {
      if (orders[i].status === OrderStatus.READY_FOR_PICKUP) {
        count = count + 1;
      }
    }
    return count;
  }, [orders]);

  // Handlers
  // [CO4]: Lifed handler to place order (lifting state modification up from StudentHub component)
  const handlePlaceOrder = (
    cartItems: { id: string; name: string; price: number; quantity: number }[], 
    specialNotes: string, 
    pickupStationId: string
  ) => {
    // [CO2]: Functional Programming - using reduce/loops for numeric values accumulation
    let subtotal = 0;
    for (let i = 0; i < cartItems.length; i++) {
      subtotal = subtotal + (cartItems[i].price * cartItems[i].quantity);
    }
    const tax = subtotal * 0.08;
    const total = subtotal + tax;

    // Deduct Student balance
    setStudent(prev => ({
      ...prev,
      walletBalance: prev.walletBalance - total,
      spentToday: prev.spentToday + total
    }));

    // Generate custom Serial Token (E.g. TC-208)
    const nextTokenNum = 208 + orders.length;
    const orderId = `or_auto_${Date.now()}`;
    const tokenString = `TC-${nextTokenNum}`;

    // Priority Check
    let order_pr = OrderPriority.MEDIUM;
    if (specialNotes.toLowerCase().includes("allergy") || specialNotes.toLowerCase().includes("allergic")) {
      order_pr = OrderPriority.HIGH;
    }

    const newOrder: Order = {
      id: orderId,
      tokenNumber: tokenString,
      studentId: student.id,
      studentName: student.name,
      studentRollNumber: student.rollNumber,
      items: cartItems,
      subtotal,
      tax,
      total,
      status: OrderStatus.QUEUED,
      priority: order_pr,
      timestamp: new Date().toISOString(),
      specialNotes,
      pickupStationId
    };

    // Add to orders list
    setOrders(prev => [newOrder, ...prev]);

    // Push local alerts in notification list
    const newAlert: CanteenNotification = {
      id: `m_alert_${Date.now()}`,
      title: "Pre-order Locked!",
      message: `Token ${tokenString} created for ₹${total.toFixed(2)}. Deducted from profile balance. Proceed to ${pickupStationId} area.`,
      type: "info",
      timestamp: new Date().toISOString(),
      isRead: false,
      orderId
    };
    setNotifications(prev => [newAlert, ...prev]);
  };

  // 2. Chef updates cooking state (Queued -> Cooking -> Ready for pickup)
  const handleUpdateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        const updated = { ...o, status: newStatus };
        if (newStatus === OrderStatus.READY_FOR_PICKUP) {
          updated.readyAt = new Date().toISOString();
          
          // Student gets immediate flash alert notification
          const pickupAlert: CanteenNotification = {
            id: `m_ready_${Date.now()}`,
            title: `🔔 ORDER READY: ${o.tokenNumber}`,
            message: `Your pre-ordered meals have been cooked! Head to physical Smart Station ${o.pickupStationId}. The desk indicator light is pulsing RED.`,
            type: "success",
            timestamp: new Date().toISOString(),
            isRead: false,
            orderId
          };
          setNotifications(n => [pickupAlert, ...n]);
        }
        return updated;
      }
      return o;
    }));
  };

  // 3. Admin / Chef elevates precedence manually
  const handleUpdateOrderPriority = (orderId: string, newPriority: OrderPriority) => {
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return { ...o, priority: newPriority };
      }
      return o;
    }));
  };

  // 4. Student scans QR token at the desk to claims meal
  const handleCompletePickup = (orderId: string) => {
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        const completeItem = { 
          ...o, 
          status: OrderStatus.PICKED_UP,
          completedAt: new Date().toISOString() 
        };

        // Notify Student of transaction clearing success
        const deliveryNote: CanteenNotification = {
          id: `m_retrieve_${Date.now()}`,
          title: `🍽️ Meal Picked Up!`,
          message: `Ticket ${o.tokenNumber} verified. Dispenser dispensed meal. Savor your fresh lunch!`,
          type: "success",
          timestamp: new Date().toISOString(),
          isRead: false,
          orderId
        };
        setNotifications(n => [deliveryNote, ...n]);

        return completeItem;
      }
      return o;
    }));
  };

  // [CO4]: Handler for Digital Balance recharge in student profile
  const handleAddFunds = (amount: number) => {
    setStudent(prev => ({
      ...prev,
      walletBalance: prev.walletBalance + amount
    }));

    const fundAlert: CanteenNotification = {
      id: `m_fund_${Date.now()}`,
      title: "Wallet topped up!",
      message: `Successfully loaded +₹${amount.toFixed(2)} to digital student account profile.`,
      type: "success",
      timestamp: new Date().toISOString(),
      isRead: false
    };
    setNotifications(prev => [fundAlert, ...prev]);
  };

  // [CO4]: Handler for Admin addition of new dishes inside current session menu
  const handleAddNewDish = (newDish: Omit<MenuItem, "id">) => {
    const freshDish: MenuItem = {
      ...newDish,
      id: `m_custom_${Date.now()}`
    };

    setMenu(prev => [...prev, freshDish]);

    const announcement: CanteenNotification = {
      id: `m_announce_${Date.now()}`,
      title: "📢 Chef Added Special!",
      message: `"${newDish.name}" has just been added. Standard spend allowances of ₹${newDish.price.toFixed(2)} apply. Pre-order now!`,
      type: "info",
      timestamp: new Date().toISOString(),
      isRead: false
    };
    setNotifications(prev => [announcement, ...prev]);
  };

  // [CO4]: Handler for Admin toggling stock availability (CO1 Virtual DOM updates cascade)
  const handleToggleStock = (dishId: string, out: boolean) => {
    setMenu(prev => prev.map(item => {
      if (item.id === dishId) {
        return { 
          ...item, 
          availableQuantity: out ? 0 : item.maxDailyLimit 
        };
      }
      return item;
    }));
  };

  // [CO4]: Handler to change safety daily allowance threshold
  const handleUpdateLimit = (newLimit: number) => {
    setStudent(prev => ({
      ...prev,
      dailyAllowanceLimit: newLimit
    }));

    const configNotify: CanteenNotification = {
      id: `m_limit_${Date.now()}`,
      title: "Spending Guards Adjusted",
      message: `Standard campus limits for student accounts adjusted to ₹${newLimit.toFixed(2)}/day.`,
      type: "warning",
      timestamp: new Date().toISOString(),
      isRead: false
    };
    setNotifications(prev => [configNotify, ...prev]);
  };

  // Notification clear helpers
  const handleClearNotifications = () => setNotifications([]);
  
  const handleMarkNotificationRead = (notifId: string) => {
    setNotifications(prev => prev.map(n => n.id === notifId ? { ...n, isRead: true } : n));
  };

  return (
    <div className="min-h-screen bg-slate-100/60 text-slate-900 flex flex-col justify-between">
      
      {/* Dynamic Master Simulator Workspace Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs h-20 md:h-16 flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 w-full flex flex-col md:flex-row justify-between items-center gap-4">
          
          {/* Logo Brand Block */}
          <div className="flex items-center space-x-3 text-slate-800">
            <div className="w-9 h-9 bg-orange-500 rounded-lg flex items-center justify-center text-white font-black text-lg tracking-tight shadow-xs shadow-orange-200">
              C
            </div>
            <div>
              <h1 className="text-lg font-display font-extrabold tracking-tight text-slate-800">
                CampusCrave <span className="text-orange-500">Pro</span>
              </h1>
              <p className="text-[9px] font-mono text-slate-500 uppercase tracking-widest flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 text-orange-500" /> Canteen pre-order hub
              </p>
            </div>
          </div>

          {/* Quick Active metrics bubble and Live Kitchen Status */}
          <div className="flex flex-wrap items-center gap-3.5">
            <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-full border border-slate-200">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider">Kitchen Online</span>
            </div>

            <div className="flex items-center gap-2 bg-slate-50 p-1 rounded-xl text-[11px] font-mono text-slate-600 border border-slate-200">
              <span className="px-2 py-0.5 rounded-lg bg-white text-slate-700 shadow-3xs border border-slate-100">
                🔥 Queue: <strong className="text-slate-950 font-black">{totalIncomingQueueCount}</strong>
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-orange-50 text-orange-700 shadow-3xs border border-orange-150">
                🍳 Cook: <strong className="font-extrabold">{totalPreparingCount}</strong>
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-800 font-extrabold animate-pulse">
                🚨 Ready: {activeReadyCount}
              </span>
            </div>
          </div>

          {/* Interface Tabs selectors - Large clickable Touch Targets */}
          <nav className="flex items-center bg-slate-105 p-1 rounded-xl self-stretch md:self-auto overflow-x-auto invisible-scrollbar border border-slate-200">
            {/* Split Screen Simulator Tab */}
            <button
              onClick={() => setActiveTab("simulation")}
              className={`px-3-5 py-1.5 rounded-lg text-xs font-semibold tracking-tight transition-all flex items-center gap-1.5 focus:outline-none whitespace-nowrap ${
                activeTab === "simulation" 
                  ? "bg-slate-900 text-white font-black shadow-sm" 
                  : "text-slate-600 hover:text-slate-900 hover:bg-white"
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Multi-View Split</span>
            </button>

            {/* Student App Portal view */}
            <button
              onClick={() => setActiveTab("student")}
              className={`px-3-5 py-1.5 rounded-lg text-xs font-semibold tracking-tight transition-all flex items-center gap-1.5 focus:outline-none whitespace-nowrap ${
                activeTab === "student" 
                  ? "bg-slate-900 text-white font-black shadow-sm" 
                  : "text-slate-600 hover:text-slate-900 hover:bg-white"
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Student App</span>
            </button>

            {/* Chef Kitchen screen */}
            <button
              onClick={() => setActiveTab("chef")}
              className={`px-3-5 py-1.5 rounded-lg text-xs font-semibold tracking-tight transition-all flex items-center gap-1.5 focus:outline-none whitespace-nowrap ${
                activeTab === "chef" 
                  ? "bg-slate-900 text-white font-black shadow-sm" 
                  : "text-slate-600 hover:text-slate-900 hover:bg-white"
              }`}
            >
              <ChefHat className="w-3.5 h-3.5" />
              <span>Chef Panel</span>
            </button>

            {/* Tablet Station light indicator */}
            <button
              onClick={() => setActiveTab("station")}
              className={`px-3-5 py-1.5 rounded-lg text-xs font-semibold tracking-tight transition-all flex items-center gap-1.5 focus:outline-none whitespace-nowrap ${
                activeTab === "station" 
                  ? "bg-slate-900 text-white font-black shadow-sm" 
                  : "text-slate-600 hover:text-slate-900 hover:bg-white"
              }`}
            >
              <Tv className="w-3.5 h-3.5" />
              <span>Smart Desk Beacon</span>
            </button>

            {/* Administration portal */}
            <button
              onClick={() => setActiveTab("admin")}
              className={`px-3-5 py-1.5 rounded-lg text-xs font-semibold tracking-tight transition-all flex items-center gap-1.5 focus:outline-none whitespace-nowrap ${
                activeTab === "admin" 
                  ? "bg-slate-900 text-white font-black shadow-sm" 
                  : "text-slate-600 hover:text-slate-900 hover:bg-white"
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Admin CFO</span>
            </button>
          </nav>

        </div>
      </header>

      {/* Primary Switchboard content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full">
        
        {/* VIEW 1: THE AMAZING ALL-IN-ONE SPLIT INTERACTIVE SIMULATOR */}
        {activeTab === "simulation" && (
          <div className="space-y-6">
            
            {/* Demonstration Banner */}
            <div className="bg-slate-900 border border-slate-800 text-white p-6 rounded-3xl relative overflow-hidden shadow-sm">
              <div className="absolute top-0 right-0 p-16 w-32 h-32 bg-orange-500/10 rounded-full blur-3xl animate-pulse" />
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1.5">
                  <h3 className="font-display font-black text-base text-white tracking-tight flex items-center gap-2">
                    <span className="w-2.5 h-2.5 bg-orange-500 rounded-full animate-pulse inline-block" />
                    Real-Time Canteen Integration Sandbox
                  </h3>
                  <p className="text-xs text-slate-350 leading-relaxed max-w-3xl font-sans">
                    Experience the complete loop on one screen! Choose delicious meals in the <strong className="text-white font-semibold">Student column (Left)</strong>, watch the ticket land instantly in the <strong className="text-white font-semibold">Chef's kitchen (Right)</strong>, cook it to light up the student's <strong className="text-white font-semibold">Smart Station desk lamp alarm</strong> below, and scan the QR token to retrieve securely.
                  </p>
                </div>
                
                <span className="bg-orange-500/10 text-orange-400 text-[10px] uppercase font-mono px-3 py-1.5 rounded-full border border-orange-500/20 shrink-0 font-bold tracking-wider">
                  Fully Synchronized
                </span>
              </div>
            </div>

            {/* Side-by-side Bento layout */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Left Wing - Student Interface */}
              <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
                <div className="flex justify-between items-center bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-2xl">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-orange-500" />
                    <span className="font-display font-bold text-xs uppercase tracking-wider text-slate-700">Simulated Student App</span>
                  </div>
                  <button 
                    onClick={() => setActiveTab("student")}
                    className="text-[10px] text-orange-500 hover:text-orange-600 font-extrabold border-none bg-transparent transition-colors cursor-pointer"
                  >
                    Go Fullscreen →
                  </button>
                </div>
                <StudentHub 
                  menu={menu}
                  student={student}
                  orders={orders}
                  notifications={notifications}
                  onPlaceOrder={handlePlaceOrder}
                  onAddFunds={handleAddFunds}
                  onClearNotifications={handleClearNotifications}
                  onMarkNotificationRead={handleMarkNotificationRead}
                  onUpdateStudent={(updated) => setStudent(updated)}
                />
              </div>

              {/* Right Wing - Chef / Kitchen Station Tablet */}
              <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4 h-fit">
                <div className="flex justify-between items-center bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-2xl">
                  <div className="flex items-center gap-2">
                    <ChefHat className="w-4 h-4 text-orange-500" />
                    <span className="font-display font-bold text-xs uppercase tracking-wider text-slate-700">Chef Touch Tablet</span>
                  </div>
                  <button 
                    onClick={() => setActiveTab("chef")}
                    className="text-[10px] text-orange-500 hover:text-orange-600 font-extrabold border-none bg-transparent transition-colors cursor-pointer"
                  >
                    Go Fullscreen →
                  </button>
                </div>
                <ChefTablet 
                  orders={orders}
                  onUpdateStatus={handleUpdateOrderStatus}
                  onUpdatePriority={handleUpdateOrderPriority}
                />
              </div>

            </div>

            {/* Smart Station visual signal module (Row below) */}
            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
              <div className="flex justify-between items-center bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-2xl">
                <div className="flex items-center gap-2">
                  <Tv className="w-4 h-4 text-orange-500" />
                  <span className="font-display font-bold text-xs uppercase tracking-wider text-slate-700">Canteen Benches & Physical Smart Table Indicator lights</span>
                </div>
                <button 
                  onClick={() => setActiveTab("station")}
                  className="text-[10px] text-orange-500 hover:text-orange-600 font-extrabold border-none bg-transparent transition-colors cursor-pointer"
                >
                  Go Fullscreen →
                </button>
              </div>
              <SmartStation 
                orders={orders}
                onCompletePickup={handleCompletePickup}
              />
            </div>

          </div>
        )}

        {/* VIEW 2: INDIVIDUAL FULLSCREEN STANDALONE - STUDENT APP */}
        {activeTab === "student" && (
          <div className="max-w-4xl mx-auto">
            <StudentHub 
              menu={menu}
              student={student}
              orders={orders}
              notifications={notifications}
              onPlaceOrder={handlePlaceOrder}
              onAddFunds={handleAddFunds}
              onClearNotifications={handleClearNotifications}
              onMarkNotificationRead={handleMarkNotificationRead}
              onUpdateStudent={(updated) => setStudent(updated)}
            />
          </div>
        )}

        {/* VIEW 3: INDIVIDUAL FULLSCREEN STANDALONE - CHEF TOUCH SCREEN */}
        {activeTab === "chef" && (
          <div className="max-w-5xl mx-auto">
            <ChefTablet 
              orders={orders}
              onUpdateStatus={handleUpdateOrderStatus}
              onUpdatePriority={handleUpdateOrderPriority}
            />
          </div>
        )}

        {/* VIEW 4: INDIVIDUAL FULLSCREEN STANDALONE - PHYSICAL SMART STATION BEACON */}
        {activeTab === "station" && (
          <div className="max-w-4xl mx-auto">
            <SmartStation 
              orders={orders}
              onCompletePickup={handleCompletePickup}
            />
          </div>
        )}

        {/* VIEW 5: INDIVIDUAL FULLSCREEN STANDALONE - CAFE REPORT PANEL */}
        {activeTab === "admin" && (
          <div className="max-w-5xl mx-auto">
            <AdminPanel 
              menu={menu}
              orders={orders}
              onAddNewDish={handleAddNewDish}
              onToggleStock={handleToggleStock}
              onUpdateLimit={handleUpdateLimit}
              currentLimit={student.dailyAllowanceLimit}
            />
          </div>
        )}

      </main>

      {/* Simple accessible design foot */}
      <footer className="bg-slate-900 py-6 text-center text-slate-500 text-xs border-t border-slate-800">
        <p className="font-mono text-[10px] tracking-wider uppercase text-slate-500">
          Campus Canteen Pre-order & Dispatch Central
        </p>
        <p className="mt-1">
          Bespoke high fidelity simulator supporting QR Tokens, daily spend safeguards, and chef touch terminals.
        </p>
      </footer>

    </div>
  );
}
