/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DietaryPreference, CanteenCategory, MenuItem, StudentProfile, Order, OrderStatus, OrderPriority, DailyAnalytics } from "./types";

export const INITIAL_MENU: MenuItem[] = [
  {
    id: "m1",
    name: "Golden Paneer Tikka Wrap",
    description: "Tandoori spiced paneer cubes grilled with bell peppers and layered with mint chutney in a whole-wheat tortilla.",
    price: 325.00,
    category: CanteenCategory.LUNCH,
    dietary: [DietaryPreference.VEGETARIAN, DietaryPreference.HALAL],
    imageUrl: "https://images.unsplash.com/photo-1626700051175-6518c4793f4f?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 45,
    maxDailyLimit: 120,
    isPopular: true
  },
  {
    id: "m2",
    name: "Spiced Chickpea & Avocado Bowl",
    description: "Crispy maple-sriracha chickpeas, fresh avocado, quinoa, roasted sweet potatoes, and organic kale with tahini drizzle.",
    price: 400.00,
    category: CanteenCategory.LUNCH,
    dietary: [DietaryPreference.VEGAN, DietaryPreference.VEGETARIAN, DietaryPreference.GLUTEN_FREE],
    imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 28,
    maxDailyLimit: 80,
    isPopular: true
  },
  {
    id: "m3",
    name: "Zesty Garden Caesar Salad",
    description: "Crisp romaine wedges, crunchy herb croutons, cherry tomatoes, shaved parmesan, and creamy house Caesar dressing.",
    price: 290.00,
    category: CanteenCategory.LUNCH,
    dietary: [DietaryPreference.VEGETARIAN, DietaryPreference.NUT_FREE],
    imageUrl: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 30,
    maxDailyLimit: 60
  },
  {
    id: "m4",
    name: "Smashed Hass Avocado Toast",
    description: "Thick sourdough slice loaded with seasoned avocado smash, direct-farm cherry tomatoes, chili flakes, and microgreens.",
    price: 260.00,
    category: CanteenCategory.BREAKFAST,
    dietary: [DietaryPreference.VEGETARIAN, DietaryPreference.VEGAN, DietaryPreference.NUT_FREE, DietaryPreference.DAIRY_FREE],
    imageUrl: "https://images.unsplash.com/photo-1541532713592-79a0317b6b77?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 20,
    maxDailyLimit: 50,
    isPopular: true
  },
  {
    id: "m5",
    name: "Sun-Dried Tomato & Feta Omelette",
    description: "Three cage-free eggs folded with Greek feta crumbs, baby spinach, roasted pine nuts, and sun-dried olives. Served with fruit salad.",
    price: 300.00,
    category: CanteenCategory.BREAKFAST,
    dietary: [DietaryPreference.VEGETARIAN, DietaryPreference.GLUTEN_FREE],
    imageUrl: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 15,
    maxDailyLimit: 40
  },
  {
    id: "m6",
    name: "Belgian Waffles with Wild Berries",
    description: "Golden buttermilk waffle stacked high, topped with fresh raspberries, blueberries, and powdered sugar. Served with pure maple syrup.",
    price: 340.00,
    category: CanteenCategory.BREAKFAST,
    dietary: [DietaryPreference.VEGETARIAN, DietaryPreference.NUT_FREE],
    imageUrl: "https://images.unsplash.com/photo-1504754524776-8f4f37790ca0?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 18,
    maxDailyLimit: 45
  },
  {
    id: "m7",
    name: "Baked Sweet Potato Fries",
    description: "Crusted rosemary sweet potato wedges roasted in coconut oil, served with smoky paprika aioli dip.",
    price: 175.00,
    category: CanteenCategory.SNACKS,
    dietary: [DietaryPreference.VEGETARIAN, DietaryPreference.GLUTEN_FREE, DietaryPreference.DAIRY_FREE, DietaryPreference.NUT_FREE, DietaryPreference.VEGAN],
    imageUrl: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 50,
    maxDailyLimit: 150
  },
  {
    id: "m8",
    name: "Artisanal Strawberry Matcha Latte",
    description: "Rich ceremonial Uji matcha hand-whisked and poured over ice, sweetened with organic strawberry compote and oat milk.",
    price: 225.00,
    category: CanteenCategory.BEVERAGES,
    dietary: [DietaryPreference.VEGAN, DietaryPreference.VEGETARIAN, DietaryPreference.DAIRY_FREE, DietaryPreference.GLUTEN_FREE, DietaryPreference.NUT_FREE],
    imageUrl: "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 40,
    maxDailyLimit: 100,
    isPopular: true
  },
  {
    id: "m9",
    name: "Cold Brew Coconut Macchiato",
    description: "24-hour slow-steeped single origin cold brew splashed with creamy coconut milk and layered with dark caramel finish.",
    price: 200.00,
    category: CanteenCategory.BEVERAGES,
    dietary: [DietaryPreference.VEGAN, DietaryPreference.VEGETARIAN, DietaryPreference.DAIRY_FREE, DietaryPreference.GLUTEN_FREE],
    imageUrl: "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 50,
    maxDailyLimit: 120
  },
  {
    id: "m10",
    name: "Double Chocolate Fudge Brownie",
    description: "Ultra-fudgy dark cocoa brownie baked with premium organic chocolate chips and filled with gooey plant-based ganache.",
    price: 160.00,
    category: CanteenCategory.DESSERTS,
    dietary: [DietaryPreference.VEGETARIAN, DietaryPreference.NUT_FREE],
    imageUrl: "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&q=80&w=400",
    availableQuantity: 25,
    maxDailyLimit: 75
  }
];

export const INITIAL_STUDENT_PROFILE: StudentProfile = {
  id: "s_2026",
  name: "Alexander Mercer",
  rollNumber: "CS-2026-483",
  email: "a.mercer@campus.edu",
  department: "Computer Science & Engineering",
  walletBalance: 2125.00,
  dailyAllowanceLimit: 1250.00, // Maximum daily budget
  spentToday: 487.50, // Already ordered breakfast today
  defaultDietaryPreferences: [DietaryPreference.VEGETARIAN, DietaryPreference.NUT_FREE],
  avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150"
};

export const INITIAL_ORDERS: Order[] = [
  {
    id: "o_1001",
    tokenNumber: "TC-201",
    studentId: "s_2026",
    studentName: "Alexander Mercer",
    studentRollNumber: "CS-2026-483",
    items: [
      { id: "m4", name: "Smashed Hass Avocado Toast", price: 260.00, quantity: 1 },
      { id: "m9", name: "Cold Brew Coconut Macchiato", price: 200.00, quantity: 1 }
    ],
    subtotal: 460.00,
    tax: 27.50,
    total: 487.50,
    status: OrderStatus.PICKED_UP,
    priority: OrderPriority.LOW,
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(), // 4 hrs ago
    pickupStationId: "STATION-2",
    completedAt: new Date(Date.now() - 3.8 * 60 * 60 * 1000).toISOString()
  },
  {
    id: "o_1002",
    tokenNumber: "TC-205",
    studentId: "s-other-1",
    studentName: "Emily Vance",
    studentRollNumber: "EE-2027-112",
    items: [
      { id: "m1", name: "Golden Paneer Tikka Wrap", price: 325.00, quantity: 2 },
      { id: "m8", name: "Artisanal Strawberry Matcha Latte", price: 225.00, quantity: 1 }
    ],
    subtotal: 875.00,
    tax: 50.00,
    total: 925.00,
    status: OrderStatus.COOKING,
    priority: OrderPriority.HIGH,
    timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(), // 15 mins ago
    pickupStationId: "STATION-4",
    specialNotes: "Wrap dynamic priority: extra mint chutney, gluten sensitive if possible"
  },
  {
    id: "o_1003",
    tokenNumber: "TC-206",
    studentId: "s-other-2",
    studentName: "Rohit Sharma",
    studentRollNumber: "ME-2025-059",
    items: [
      { id: "m2", name: "Spiced Chickpea & Avocado Bowl", price: 400.00, quantity: 1 }
    ],
    subtotal: 400.00,
    tax: 25.00,
    total: 425.00,
    status: OrderStatus.QUEUED,
    priority: OrderPriority.MEDIUM,
    timestamp: new Date(Date.now() - 8 * 60 * 1000).toISOString(), // 8 mins ago
    pickupStationId: "STATION-1"
  },
  {
    id: "o_1004",
    tokenNumber: "TC-207",
    studentId: "s-other-3",
    studentName: "Clara Dubois",
    studentRollNumber: "BI-2028-904",
    items: [
      { id: "m6", name: "Belgian Waffles with Wild Berries", price: 340.00, quantity: 1 },
      { id: "m10", name: "Double Chocolate Fudge Brownie", price: 160.00, quantity: 1 }
    ],
    subtotal: 500.00,
    tax: 30.00,
    total: 530.00,
    status: OrderStatus.READY_FOR_PICKUP,
    priority: OrderPriority.HIGH,
    timestamp: new Date(Date.now() - 25 * 60 * 1000).toISOString(), // 25 mins ago
    pickupStationId: "STATION-3",
    readyAt: new Date(Date.now() - 10 * 60 * 1000).toISOString()
  }
];

export const HISTORICAL_ANALYTICS: DailyAnalytics[] = [
  {
    date: "May 28",
    totalSales: 22512.50,
    orderCount: 52,
    averageOrderValue: 432.50,
    categoryBreakdown: { "Breakfast": 6000, "Lunch/Main Course": 10500, "Snacks & Sides": 2750, "Beverages": 2250, "Desserts": 1012.50 },
    dietaryBreakdown: { "Vegetarian": 35, "Vegan": 15, "Gluten-Free": 12, "Halal": 8, "Nut-Free": 25 }
  },
  {
    date: "May 29",
    totalSales: 25600.00,
    orderCount: 61,
    averageOrderValue: 419.50,
    categoryBreakdown: { "Breakfast": 7000, "Lunch/Main Course": 12000, "Snacks & Sides": 3000, "Beverages": 2500, "Desserts": 1100 },
    dietaryBreakdown: { "Vegetarian": 40, "Vegan": 18, "Gluten-Free": 14, "Halal": 10, "Nut-Free": 30 }
  },
  {
    date: "May 30",
    totalSales: 19775.00,
    orderCount: 45,
    averageOrderValue: 439.00,
    categoryBreakdown: { "Breakfast": 5500, "Lunch/Main Course": 9250, "Snacks & Sides": 2000, "Beverages": 2000, "Desserts": 1025 },
    dietaryBreakdown: { "Vegetarian": 28, "Vegan": 12, "Gluten-Free": 10, "Halal": 6, "Nut-Free": 22 }
  },
  {
    date: "May 31",
    totalSales: 29037.50,
    orderCount: 72,
    averageOrderValue: 403.00,
    categoryBreakdown: { "Breakfast": 8250, "Lunch/Main Course": 13750, "Snacks & Sides": 3500, "Beverages": 2500, "Desserts": 1037.50 },
    dietaryBreakdown: { "Vegetarian": 48, "Vegan": 22, "Gluten-Free": 18, "Halal": 15, "Nut-Free": 35 }
  },
  {
    date: "June 01",
    totalSales: 31275.00,
    orderCount: 79,
    averageOrderValue: 395.50,
    categoryBreakdown: { "Breakfast": 8500, "Lunch/Main Course": 14500, "Snacks & Sides": 4000, "Beverages": 3000, "Desserts": 1275 },
    dietaryBreakdown: { "Vegetarian": 52, "Vegan": 26, "Gluten-Free": 20, "Halal": 18, "Nut-Free": 40 }
  },
  {
    date: "June 02",
    totalSales: 34200.00,
    orderCount: 85,
    averageOrderValue: 402.00,
    categoryBreakdown: { "Breakfast": 9750, "Lunch/Main Course": 15500, "Snacks & Sides": 4250, "Beverages": 3250, "Desserts": 1450 },
    dietaryBreakdown: { "Vegetarian": 58, "Vegan": 28, "Gluten-Free": 24, "Halal": 22, "Nut-Free": 45 }
  }
];
