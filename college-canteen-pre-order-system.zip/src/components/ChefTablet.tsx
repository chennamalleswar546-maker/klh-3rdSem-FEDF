/**
 * =========================================================================
 * SUB-COMPONENT: ChefTablet.tsx
 * COURSE OUTCOME (CO) MAPPINGS IN THIS FILE:
 * - [CO1] Foundations: Component-driven thinking, handling high kitchen prep loads.
 * - [CO2] TS Engineering: TypeScript strict types for OrderStatus, OrderPriority.
 * - [CO3] React Component Model: Side-effects, dynamic props handlers for pre-order status changes.
 * - [CO4] State Architecture: Lifted action callbacks, custom sorting and filter pipelines.
 * - [CO5] Forms & Accessibility: Live sorting toggles, visual colors with contrast for cooks.
 * =========================================================================
 */

import React, { useState, useMemo } from "react";
import { Order, OrderStatus, OrderPriority } from "../types";
import { 
  Flame, 
  Clock, 
  Trash, 
  Play, 
  Check, 
  AlertTriangle, 
  ChefHat, 
  RefreshCw, 
  Filter,
  CheckCircle,
  HelpCircle,
  TrendingUp,
  Tag
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ChefTabletProps {
  orders: Order[];
  onUpdateStatus: (orderId: string, newStatus: OrderStatus) => void;
  onUpdatePriority: (orderId: string, newPriority: OrderPriority) => void;
}

export default function ChefTablet({
  orders,
  onUpdateStatus,
  onUpdatePriority
}: ChefTabletProps) {
  // [CO3]: Component state variables representing display configurations
  const [stationFilter, setStationFilter] = useState<"All" | "Hot Kitchen" | "Bakery & Desserts" | "Beverage Press">("All");
  const [sortBy, setSortBy] = useState<"priority" | "time">("priority");

  // [CO4]: Derived State (Filter orders related only to active/under preparation states using standard loops)
  const activeOrders = useMemo(() => {
    let result: Order[] = [];
    for (let i = 0; i < orders.length; i++) {
      const o = orders[i];
      if (o.status !== OrderStatus.PICKED_UP && o.status !== OrderStatus.CANCELLED) {
        result.push(o);
      }
    }
    return result;
  }, [orders]);

  // [CO4, CO2]: Map menu categories to chef physical station labels
  // Explicit amateur check for station membership 
  const filterByStation = (order: Order) => {
    if (stationFilter === "All") {
      return true;
    }
    
    // Scan items inside order
    let hasBeverages = false;
    let hasBakery = false;
    let hasKitchenHot = false;

    for (let i = 0; i < order.items.length; i++) {
      const itemId = order.items[i].id;
      if (itemId === "m8" || itemId === "m9") {
        hasBeverages = true;
      }
      if (itemId === "m6" || itemId === "m10") {
        hasBakery = true;
      }
      if (itemId === "m1" || itemId === "m2" || itemId === "m3" || itemId === "m4" || itemId === "m5" || itemId === "m7") {
        hasKitchenHot = true;
      }
    }

    if (stationFilter === "Beverage Press") {
      return hasBeverages;
    }
    if (stationFilter === "Bakery & Desserts") {
      return hasBakery;
    }
    if (stationFilter === "Hot Kitchen") {
      return hasKitchenHot;
    }
    return true;
  };

  // [CO4]: Multi-factor prioritization pipeline using standard array sorting (CO2 principles)
  const sortedAndFilteredOrders = useMemo(() => {
    // 1. Gather all qualified files for this station using custom loop
    let qualified: Order[] = [];
    for (let i = 0; i < activeOrders.length; i++) {
      if (filterByStation(activeOrders[i])) {
        qualified.push(activeOrders[i]);
      }
    }
    
    // 2. Perform simple bubble-sort/standard sorting
    qualified.sort((a, b) => {
      if (sortBy === "priority") {
        // Higher scores represent urgent tickets
        const priorityScore = {
          [OrderPriority.CRITICAL]: 4,
          [OrderPriority.HIGH]: 3,
          [OrderPriority.MEDIUM]: 2,
          [OrderPriority.LOW]: 1,
        };
        const scoreDiff = priorityScore[b.priority] - priorityScore[a.priority];
        if (scoreDiff !== 0) {
          return scoreDiff;
        }
      }
      
      // Default: oldest order gets prepared first
      const timeA = new Date(a.timestamp).getTime();
      const timeB = new Date(b.timestamp).getTime();
      return timeA - timeB;
    });

    return qualified;
  }, [activeOrders, sortBy, stationFilter]);

  // [CO4]: Calculated Metrics for the top kitchen dashboard
  const chefKitchenStats = useMemo(() => {
    let cookingCount = 0;
    let queuedCount = 0;
    let readyCount = 0;
    let servedCount = 0;

    for (let i = 0; i < orders.length; i++) {
      const order = orders[i];
      if (order.status === OrderStatus.COOKING) {
        cookingCount = cookingCount + 1;
      } else if (order.status === OrderStatus.QUEUED) {
        queuedCount = queuedCount + 1;
      } else if (order.status === OrderStatus.READY_FOR_PICKUP) {
        readyCount = readyCount + 1;
      } else if (order.status === OrderStatus.PICKED_UP) {
        servedCount = servedCount + 1;
      }
    }
    
    return { 
      cooking: cookingCount, 
      queued: queuedCount, 
      ready: readyCount, 
      totalServedSession: servedCount 
    };
  }, [orders]);

  const toggleSort = () => {
    setSortBy(prev => prev === "priority" ? "time" : "priority");
  };

  const priorityColors = {
    [OrderPriority.CRITICAL]: { bg: "bg-rose-500", text: "text-white", border: "border-rose-600 animate-pulse" },
    [OrderPriority.HIGH]: { bg: "bg-amber-500", text: "text-white", border: "border-amber-500" },
    [OrderPriority.MEDIUM]: { bg: "bg-blue-500", text: "text-white", border: "border-blue-400" },
    [OrderPriority.LOW]: { bg: "bg-slate-500", text: "text-slate-100", border: "border-slate-400" },
  };

  return (
    <div className="space-y-6">
      
      {/* Upper Grid Kitchen Stats metrics bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Queued Stats */}
        <div className="bg-white p-5 rounded-3xl border border-slate-205 shadow-sm flex items-center gap-3 transition-shadow duration-200 hover:shadow-md">
          <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-mono font-black text-lg border border-slate-200">
            {chefKitchenStats.queued}
          </div>
          <div>
            <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400 font-bold">Incoming Queue</p>
            <p className="text-sm font-black text-slate-800">Waiting Prep</p>
          </div>
        </div>

        {/* Preparing Stats */}
        <div className="bg-white p-5 rounded-3xl border border-slate-205 shadow-sm flex items-center gap-3 transition-shadow duration-200 hover:shadow-md">
          <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-mono font-black text-lg border border-orange-100/40 animate-pulse">
            {chefKitchenStats.cooking}
          </div>
          <div>
            <p className="text-[10px] uppercase font-mono tracking-wider text-orange-500 font-bold">Firing Stove</p>
            <p className="text-sm font-black text-slate-800">Active Prep</p>
          </div>
        </div>

        {/* Ready Stats */}
        <div className="bg-white p-5 rounded-3xl border border-slate-205 shadow-sm flex items-center gap-3 transition-shadow duration-200 hover:shadow-md">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-mono font-black text-lg border border-emerald-100/40">
            {chefKitchenStats.ready}
          </div>
          <div>
            <p className="text-[10px] uppercase font-mono tracking-wider text-emerald-500 font-bold">Ready in Pass</p>
            <p className="text-sm font-black text-slate-800">For Pickup</p>
          </div>
        </div>

        {/* Served Stats */}
        <div className="bg-white p-5 rounded-3xl border border-slate-205 shadow-sm flex items-center gap-3 transition-shadow duration-200 hover:shadow-md">
          <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-mono font-black text-lg border border-orange-100/40">
            {chefKitchenStats.totalServedSession}
          </div>
          <div>
            <p className="text-[10px] uppercase font-mono tracking-wider text-orange-500 font-bold">Fulfilled</p>
            <p className="text-sm font-black text-slate-800">Served Today</p>
          </div>
        </div>
      </div>

      {/* Control filters panel */}
      <div className="bg-slate-50 border border-slate-200 text-slate-800 p-5 rounded-3xl flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4 shadow-sm">
        <div className="flex items-center gap-2">
          <ChefHat className="text-orange-500 w-5 h-5" />
          <div>
            <h3 className="font-display font-black text-sm uppercase tracking-wide text-slate-800">Chef Prep Pass Console</h3>
            <p className="text-[10px] text-slate-400 font-bold font-mono">Live streaming feed • Tablet terminal v4.2</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[10px] font-mono text-slate-400 font-bold uppercase tracking-wider mr-1">
            Area:
          </span>
          {["All", "Hot Kitchen", "Bakery & Desserts", "Beverage Press"].map((stationId) => (
            <button
              key={stationId}
              onClick={() => setStationFilter(stationId as any)}
              className={`text-[10px] md:text-xs px-3.5 py-1.5 rounded-full font-extrabold transition-all cursor-pointer ${
                stationFilter === stationId 
                  ? "bg-slate-900 text-white shadow-xs" 
                  : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-250"
              }`}
            >
              {stationId}
            </button>
          ))}
        </div>

        {/* Sorting controls */}
        <button
          onClick={toggleSort}
          className="bg-orange-500 hover:bg-orange-600 border-none text-white px-4 py-2 rounded-xl text-xs font-bold leading-none uppercase tracking-wide flex items-center gap-1.5 ml-auto md:ml-0 cursor-pointer shadow-3xs"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Sort: {sortBy === "priority" ? "Priority" : "Time"}</span>
        </button>
      </div>

      {/* Primary orders cooking pass queue */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <AnimatePresence mode="popLayout">
          {sortedAndFilteredOrders.length > 0 ? (
            sortedAndFilteredOrders.map((order) => {
              const minutesAgo = Math.max(0, Math.floor((Date.now() - new Date(order.timestamp).getTime()) / 60000));
              const isSevereNotes = order.specialNotes && (
                order.specialNotes.toLowerCase().includes("allergy") || 
                order.specialNotes.toLowerCase().includes("allergic") || 
                order.specialNotes.toLowerCase().includes("sensitive")
              );

              return (
                <motion.div
                  key={order.id}
                  layout
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  id={`chef-ticket-${order.id}`}
                  className="bg-white rounded-3xl overflow-hidden border border-slate-200 hover:border-slate-300 shadow-sm flex flex-col justify-between"
                >
                  {/* Ticket header with colored priority banner and Token */}
                  <div className={`p-4 ${
                    order.status === OrderStatus.COOKING ? 'bg-amber-500/10 border-b border-amber-200' : 'bg-slate-50 border-b border-slate-100'
                  }`}>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-xl font-black font-mono tracking-tight text-slate-950">
                        {order.tokenNumber}
                      </span>
                      
                      {/* Priority toggle button */}
                      <div className="flex items-center gap-1.5">
                        <span className={`text-[9px] font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                          priorityColors[order.priority].bg
                        } ${priorityColors[order.priority].text}`}>
                          {order.priority}
                        </span>
                        
                        {/* Instant manual escalation buttons */}
                        {order.priority !== OrderPriority.CRITICAL && (
                          <button
                            title="Escalate priority"
                            onClick={() => onUpdatePriority(order.id, OrderPriority.CRITICAL)}
                            className="bg-rose-50 text-rose-650 hover:bg-rose-100 text-[9px] px-2 py-0.5 rounded-md font-bold focus:outline-none cursor-pointer border border-rose-200"
                          >
                            ⚠️ Escalate
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
                      <span className="font-bold truncate max-w-[130px]">{order.studentName}</span>
                      <span className="flex items-center gap-0.5 font-bold">
                        <Clock className="w-3 h-3 text-orange-500 animate-pulse" /> {minutesAgo}m ago
                      </span>
                    </div>
                  </div>

                  {/* Body list of items needing prep */}
                  <div className="p-4 flex-1 space-y-3">
                    <div className="space-y-1">
                      <p className="text-[10px] uppercase tracking-widest text-slate-400 font-mono font-bold">Menu item tasks</p>
                      <div className="space-y-2">
                        {order.items.map((it) => (
                          <div key={it.id} className="flex justify-between items-start text-xs border-b border-slate-100 pb-1.5">
                            <div className="flex items-baseline space-x-1.5">
                              {/* Quantity counter - highly visual block */}
                              <span className="bg-slate-900 text-white font-mono text-[10px] font-extrabold w-5 h-5 rounded-md flex items-center justify-center">
                                {it.quantity}
                              </span>
                              <span className="font-semibold text-slate-800 tracking-tight">{it.name}</span>
                            </div>
                            <span className="text-[10px] text-slate-500 font-mono font-bold">₹{(it.price * it.quantity).toFixed(2)}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Special requests allergins caution banner */}
                    {order.specialNotes && (
                      <div className={`p-2.5 rounded-xl text-xs flex gap-2 ${
                        isSevereNotes 
                          ? "bg-rose-50 border border-rose-200 text-rose-800 font-bold" 
                          : "bg-slate-50 border border-slate-205 text-slate-700 font-medium"
                      }`}>
                        <AlertTriangle className={`w-4 h-4 shrink-0 mt-0.5 ${isSevereNotes ? 'text-rose-600' : 'text-slate-400'}`} />
                        <div className="leading-tight">
                          <span className="text-[9px] uppercase font-mono tracking-wider block opacity-70">Kitchen Directive:</span>
                          <span className="text-[11px] font-sans">{order.specialNotes}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Bottom Ticket status workflow action buttons */}
                  <div className="p-4 bg-slate-50/80 border-t border-slate-150 grid grid-cols-2 gap-2">
                    {/* Switch status to Cooking */}
                    {order.status === OrderStatus.QUEUED ? (
                      <button
                        onClick={() => onUpdateStatus(order.id, OrderStatus.COOKING)}
                        className="col-span-2 bg-orange-500 text-white hover:bg-orange-600 py-3 rounded-2xl text-[10px] uppercase tracking-wider font-extrabold flex items-center justify-center gap-1.5 transition-all focus:outline-none shadow-sm cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Confirm & Prep</span>
                      </button>
                    ) : order.status === OrderStatus.COOKING ? (
                      <>
                        {/* Switch back to queued safety */}
                        <button
                          onClick={() => onUpdateStatus(order.id, OrderStatus.QUEUED)}
                          className="bg-white text-slate-505 hover:bg-slate-100 py-2.5 rounded-2xl text-[10px] uppercase tracking-wider font-extrabold border border-slate-200 transition-all focus:outline-none cursor-pointer"
                        >
                          Hold Queue
                        </button>
                        {/* Direct Mark as ready */}
                        <button
                          onClick={() => onUpdateStatus(order.id, OrderStatus.READY_FOR_PICKUP)}
                          className="bg-emerald-600 text-white hover:bg-emerald-700 py-2.5 rounded-2xl text-[10px] uppercase tracking-wider font-extrabold flex items-center justify-center gap-1 transition-all focus:outline-none shadow-sm cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Ready!</span>
                        </button>
                      </>
                    ) : (
                      <div className="col-span-2 bg-emerald-50 border border-emerald-200 rounded-2xl p-2.5 text-center text-xs font-bold text-emerald-800 flex items-center justify-center gap-1.5">
                        <CheckCircle className="w-4 h-4 text-emerald-600" />
                        <span>Ready at Pick Pass • Desk Lit</span>
                      </div>
                    )}
                  </div>

                </motion.div>
              );
            })
          ) : (
            <div className="bg-white py-16 text-center rounded-3xl border border-slate-250 col-span-3 space-y-3 p-6 shadow-xs">
              <ChefHat className="w-12 h-12 text-slate-305 mx-auto" />
              <div className="space-y-1">
                <p className="text-slate-800 font-bold text-base">Preparing Pass is Clean</p>
                <p className="text-slate-400 text-xs max-w-sm mx-auto leading-normal">
                  All active canteen pre-orders are cooked and served. Students are eating in peace. New bookings stream in real-time.
                </p>
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}
