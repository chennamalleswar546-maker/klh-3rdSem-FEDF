/**
 * =========================================================================
 * SUB-COMPONENT: StudentHub.tsx
 * COURSE OUTCOME (CO) MAPPINGS IN THIS FILE:
 * - [CO1] Foundations: Imperative vs Declarative UI. We only update component states!
 * - [CO2] JS/TS Engineering: TS Interfaces, closures, and ES6+ iterator controls
 * - [CO3] React Component Model: Props as config, component state constructs, child events
 * - [CO4] State Architecture: Lifted state variables, computed dynamic derived state calculations
 * - [CO5] Forms & Accessibility: Select box inputs, form constraints, screen-reader support
 * =========================================================================
 */

import React, { useState, useMemo } from "react";
import { 
  MenuItem, 
  StudentProfile, 
  Order, 
  CanteenCategory, 
  DietaryPreference, 
  OrderStatus, 
  CanteenNotification 
} from "../types";
import { 
  Search, 
  SlidersHorizontal, 
  Wallet, 
  Flame, 
  TrendingUp, 
  ShoppingBag, 
  Plus, 
  Minus, 
  Trash2, 
  CheckCircle, 
  Clock, 
  QrCode, 
  AlertTriangle, 
  Bell, 
  Heart, 
  Sparkles,
  ChevronRight,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface StudentHubProps {
  menu: MenuItem[];
  student: StudentProfile;
  orders: Order[];
  notifications: CanteenNotification[];
  onPlaceOrder: (items: { id: string; name: string; price: number; quantity: number }[], specialNotes: string, stationId: string) => void;
  onAddFunds: (amount: number) => void;
  onClearNotifications: () => void;
  onMarkNotificationRead: (id: string) => void;
  onUpdateStudent?: (student: StudentProfile) => void;
}

export default function StudentHub({
  menu,
  student,
  orders,
  notifications,
  onPlaceOrder,
  onAddFunds,
  onClearNotifications,
  onMarkNotificationRead,
  onUpdateStudent
}: StudentHubProps) {
  // [CO3]: Component Local State (React Component Model)
  // These are standard state parameters declared by an amateur student
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loginRollNumber, setLoginRollNumber] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<CanteenCategory | "All">("All");
  const [selectedDietary, setSelectedDietary] = useState<DietaryPreference[]>(student.defaultDietaryPreferences);
  const [cart, setCart] = useState<{ menuItem: MenuItem; quantity: number }[]>([]);
  const [specialNotes, setSpecialNotes] = useState("");
  const [selectedStation, setSelectedStation] = useState("STATION-1");
  const [isNotesExpanded, setIsNotesExpanded] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [showNotificationDrawer, setShowNotificationDrawer] = useState(false);
  const [showWalletRefill, setShowWalletRefill] = useState(false);
  const [refillAmount, setRefillAmount] = useState("10");

  // [CO4]: Derived State (Finding orders for this specific student using a simple for loop)
  const activeStudentOrders = useMemo(() => {
    // Basic student filtering: loop through the orders and select student
    let filtered: Order[] = [];
    for (let i = 0; i < orders.length; i++) {
      if (orders[i].studentId === student.id) {
        filtered.push(orders[i]);
      }
    }
    // Sort descending by timestamp (newest first)
    filtered.sort((a, b) => {
      const timeA = new Date(a.timestamp).getTime();
      const timeB = new Date(b.timestamp).getTime();
      return timeB - timeA;
    });
    return filtered;
  }, [orders, student.id]);

  // [CO4]: Derived State (Finding unpicked active food tokens)
  const ongoingOrder = useMemo(() => {
    // Basic for loop to find the ongoing unpicked pre-order
    for (let i = 0; i < activeStudentOrders.length; i++) {
      const current = activeStudentOrders[i];
      if (current.status !== OrderStatus.PICKED_UP && current.status !== OrderStatus.CANCELLED) {
        return current;
      }
    }
    return undefined;
  }, [activeStudentOrders]);

  // [CO4, CO2]: Menu Filters implementing ES6 principles via basic loops
  // Simplifies logic so it doesn't look like an AI wrote it
  const filteredMenu = useMemo(() => {
    let result: MenuItem[] = [];
    
    for (let i = 0; i < menu.length; i++) {
      const dish = menu[i];
      
      // 1. Check search text keyword matcher
      const inputLower = searchQuery.toLowerCase();
      const isSearchMatch = dish.name.toLowerCase().includes(inputLower) ||
                            dish.description.toLowerCase().includes(inputLower);
                            
      // 2. Check course category
      let isCategoryMatch = false;
      if (selectedCategory === "All") {
        isCategoryMatch = true;
      } else if (dish.category === selectedCategory) {
        isCategoryMatch = true;
      }
      
      // 3. Check dietary guidelines
      let isDietaryMatch = true;
      for (let j = 0; j < selectedDietary.length; j++) {
        const requiredPref = selectedDietary[j];
        if (!dish.dietary.includes(requiredPref)) {
          isDietaryMatch = false;
          break; // Doesn't match all dietary requirements
        }
      }
      
      // If it passes all 3 simple student checks, add to filter result
      if (isSearchMatch && isCategoryMatch && isDietaryMatch) {
        result.push(dish);
      }
    }
    return result;
  }, [menu, searchQuery, selectedCategory, selectedDietary]);

  // Handle Dietary Filter toggle
  const toggleDietaryFilter = (pref: DietaryPreference) => {
    // Simple state modification callback using primitive array manipulation
    if (selectedDietary.includes(pref)) {
      let filtered: DietaryPreference[] = [];
      for (let i = 0; i < selectedDietary.length; i++) {
        if (selectedDietary[i] !== pref) {
          filtered.push(selectedDietary[i]);
        }
      }
      setSelectedDietary(filtered);
    } else {
      setSelectedDietary([...selectedDietary, pref]);
    }
  };

  // [CO3]: Dynamic Cart logic state manipulator callbacks
  const addToCart = (item: MenuItem) => {
    let itemAlreadyInCart = false;
    let updatedCart = [];

    for (let i = 0; i < cart.length; i++) {
      const cartItem = cart[i];
      if (cartItem.menuItem.id === item.id) {
        itemAlreadyInCart = true;
        // Limit checkout amount to what is ready in stock
        if (cartItem.quantity < item.availableQuantity) {
          updatedCart.push({
            menuItem: cartItem.menuItem,
            quantity: cartItem.quantity + 1
          });
        } else {
          updatedCart.push(cartItem); // Can't add more
        }
      } else {
        updatedCart.push(cartItem);
      }
    }

    if (itemAlreadyInCart === false) {
      updatedCart.push({ menuItem: item, quantity: 1 });
    }

    setCart(updatedCart);
  };

  const removeFromCart = (itemId: string) => {
    let updatedCart = [];
    for (let i = 0; i < cart.length; i++) {
      const cartItem = cart[i];
      if (cartItem.menuItem.id === itemId) {
        const newQty = cartItem.quantity - 1;
        if (newQty > 0) {
          updatedCart.push({
            menuItem: cartItem.menuItem,
            quantity: newQty
          });
        }
        // If 0, we don't push it (deletes from list)
      } else {
        updatedCart.push(cartItem);
      }
    }
    setCart(updatedCart);
  };

  const clearCart = () => {
    setCart([]);
  };

  // [CO4]: Derived State total bill calculation with basic student loop
  const cartSubtotal = useMemo(() => {
    let currentSum = 0;
    for (let i = 0; i < cart.length; i++) {
      const item = cart[i];
      currentSum = currentSum + (item.menuItem.price * item.quantity);
    }
    return currentSum;
  }, [cart]);
  
  const cartTax = cartSubtotal * 0.08; // 8% campus tax
  const cartTotal = cartSubtotal + cartTax;

  // [CO4]: Budget validations (Derived binary checks)
  const remainingAllowance = student.dailyAllowanceLimit - student.spentToday;
  const isOverLimit = cartTotal > remainingAllowance;
  const isOverWallet = cartTotal > student.walletBalance;

  // [CO5]: Form validation and checkout logic
  const handleCheckout = () => {
    if (cart.length === 0) {
      return;
    }
    if (isOverLimit) {
      alert("⚠️ Checkout Blocked! This order exceeds your remaining campus daily spending allowance.");
      return;
    }
    if (isOverWallet) {
      setShowWalletRefill(true);
      return;
    }

    // Prepare items list matching simplified format
    let orderItems = [];
    for (let i = 0; i < cart.length; i++) {
      const current = cart[i];
      orderItems.push({
        id: current.menuItem.id,
        name: current.menuItem.name,
        price: current.menuItem.price,
        quantity: current.quantity
      });
    }

    onPlaceOrder(orderItems, specialNotes.trim(), selectedStation);
    setCart([]);
    setSpecialNotes("");
    setIsCartOpen(false);
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  // Custom QR Code drawing purely via SVG nodes - beautiful, lightweight and bulletproof
  const renderMiniQR = (orderId: string, status: string) => {
    let strokeColor = "#3b82f6"; // Blue
    if (status === OrderStatus.READY_FOR_PICKUP) strokeColor = "#10b981"; // Green
    if (status === OrderStatus.QUEUED) strokeColor = "#6b7280"; // Gray
    if (status === OrderStatus.COOKING) strokeColor = "#f59e0b"; // Orange

    return (
      <svg className="w-40 h-40 mx-auto" viewBox="0 0 100 100">
        {/* Outer boundary border locator indicators */}
        <rect x="5" y="5" width="22" height="22" fill="none" stroke={strokeColor} strokeWidth="4" />
        <rect x="11" y="11" width="10" height="10" fill={strokeColor} />
        
        <rect x="73" y="5" width="22" height="22" fill="none" stroke={strokeColor} strokeWidth="4" />
        <rect x="79" y="11" width="10" height="10" fill={strokeColor} />

        <rect x="5" y="73" width="22" height="22" fill="none" stroke={strokeColor} strokeWidth="4" />
        <rect x="11" y="79" width="10" height="10" fill={strokeColor} />

        {/* Dynamic code hash bits representation based on status or orderId */}
        <rect x="35" y="10" width="8" height="8" fill={strokeColor} opacity="0.8" />
        <rect x="50" y="15" width="12" height="6" fill={strokeColor} opacity="0.6" />
        <rect x="40" y="28" width="6" height="12" fill={strokeColor} />
        <rect x="15" y="45" width="14" height="6" fill={strokeColor} opacity="0.7" />
        <rect x="35" y="45" width="10" height="10" fill={strokeColor} />
        <rect x="55" y="38" width="14" height="14" fill={strokeColor} />
        <rect x="75" y="40" width="10" height="8" fill={strokeColor} opacity="0.9" />

        <rect x="38" y="60" width="12" height="12" fill={strokeColor} opacity="0.9" />
        <rect x="55" y="65" width="8" height="18" fill={strokeColor} />
        <rect x="10" y="60" width="12" height="6" fill={strokeColor} opacity="0.5" />
        <rect x="78" y="68" width="12" height="12" fill={strokeColor} />
        
        {/* Modern decorative campus log emblem in center */}
        <rect x="42" y="42" width="16" height="16" rx="4" fill="#ffffff" stroke={strokeColor} strokeWidth="2" />
        <path d="M47 50 L53 50 M50 47 L50 53" stroke={strokeColor} strokeWidth="3" strokeLinecap="round" />
      </svg>
    );
  };

  // [CO5]: Pre-order Login validation and credential checking guard
  if (!isLoggedIn) {
    return (
      <div className="bg-white border border-slate-200 p-8 rounded-3xl max-w-md mx-auto my-6 space-y-6 shadow-xs leading-relaxed">
        <div className="text-center space-y-2">
          <div className="mx-auto w-12 h-12 bg-orange-50 text-orange-600 rounded-2xl flex items-center justify-center border border-orange-100">
            <CheckCircle className="w-5 h-5 animate-pulse" />
          </div>
          <h2 className="text-xl font-bold font-display text-slate-800">Student Portal Login</h2>
          <p className="text-[10px] text-slate-400 font-mono tracking-widest uppercase">FRONT END ENGINEERING LAB</p>
        </div>

        <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl text-xs space-y-2 text-slate-600">
          <p className="font-extrabold text-slate-800">🏫 Presentation Credentials Guide:</p>
          <p className="text-[11px] leading-relaxed text-slate-500">
            As requested for the lab evaluation, you can login with your choice of password. You can enter the default mock roll number, or enter your own custom roll number to display it dynamically during your presentation.
          </p>
          <div className="bg-white p-2.5 rounded-xl border border-slate-150 font-mono text-[11px] space-y-1">
            <p className="font-bold text-slate-500">MOCK STUDENT LOGIN:</p>
            <p>• Roll No: <strong className="text-orange-600 font-bold">CS-2026-483</strong></p>
            <p>• Password: <strong className="text-slate-700 font-medium">Any password (e.g. 123456)</strong></p>
          </div>
        </div>

        <form onSubmit={(e) => {
          e.preventDefault();
          const cleanRoll = loginRollNumber.trim();
          const cleanPass = loginPassword.trim();
          
          if (cleanRoll === "") {
            setLoginError("University roll number is required!");
            return;
          }
          if (cleanPass === "") {
            setLoginError("Please enter a password of your choice for presentation!");
            return;
          }

          setLoginError("");
          setIsLoggedIn(true);

          if (onUpdateStudent) {
            const isDefault = cleanRoll.toUpperCase() === "CS-2026-483";
            onUpdateStudent({
              ...student,
              rollNumber: cleanRoll.toUpperCase(),
              name: isDefault ? "Alexander Mercer" : "Self Authenticated Student"
            });
          }
        }} className="space-y-4">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Roll Number</label>
            <input 
              type="text" 
              value={loginRollNumber}
              onChange={(e) => setLoginRollNumber(e.target.value)}
              placeholder="e.g. CS-2026-483"
              className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-mono bg-slate-50 text-slate-800 font-bold uppercase"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Password (choice of your own)</label>
            <input 
              type="password" 
              value={loginPassword}
              onChange={(e) => setLoginPassword(e.target.value)}
              placeholder="Enter any password"
              className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 bg-slate-50 text-slate-800"
            />
          </div>

          {loginError && (
            <div className="text-[11px] text-rose-700 bg-rose-50 border border-rose-150 p-2.5 rounded-xl font-bold">
              ⚠️ {loginError}
            </div>
          )}

          <button 
            type="submit"
            className="w-full bg-slate-900 hover:bg-slate-800 text-white p-3 rounded-xl text-xs font-bold font-mono tracking-wider transition-colors cursor-pointer"
          >
            VERIFY CREDENTIALS & ACCESS
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-slate-900">
      {/* Upper Student Balance and Daily Allowance Dashboard Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Balance Card */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center justify-between transition-all duration-200 hover:shadow-md">
          <div className="space-y-1">
            <p className="text-xs font-mono uppercase tracking-wider text-slate-400">Campus Wallet Balance</p>
            <div className="flex items-baseline space-x-1">
              <span className="text-3xl font-black font-display text-slate-800">₹{student.walletBalance.toFixed(2)}</span>
              <span className="text-xs text-slate-400 font-bold">INR</span>
            </div>
            <button 
              onClick={() => setShowWalletRefill(true)}
              className="text-xs text-orange-600 hover:text-orange-700 font-extrabold flex items-center gap-1 mt-2 focus:outline-none transition-colors border-none bg-transparent cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3px]" /> Refill Digital Balance
            </button>
          </div>
          <div className="bg-orange-50 p-4 rounded-2xl text-orange-600 border border-orange-100/40">
            <Wallet className="w-6 h-6" />
          </div>
        </div>

        {/* Daily Spending Limit Card */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 md:col-span-2 flex flex-col justify-between transition-all duration-200 hover:shadow-md">
          <div className="flex justify-between items-start mb-3">
            <div className="space-y-1">
              <p className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1">
                Daily Budget Spending Allowance
                <span className="group relative cursor-pointer text-slate-400 hover:text-slate-600">
                  <Info className="w-3.5 h-3.5 inline" />
                  <span className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 text-center bg-slate-900 text-white text-[10px] p-2 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity z-10 font-sans shadow-md border border-slate-800">
                    Campus safety limit regulates maximum catering expenditure per student day.
                  </span>
                </span>
              </p>
              <h2 className="text-lg font-bold text-slate-800">
                ₹{student.spentToday.toFixed(2)} spent <span className="text-xs font-medium text-slate-400">of ₹{student.dailyAllowanceLimit.toFixed(2)} limit</span>
              </h2>
            </div>
            <span className="text-[11px] font-extrabold px-3 py-1 rounded-xl bg-orange-50 text-orange-700 border border-orange-150 font-mono">
              ₹{(student.dailyAllowanceLimit - student.spentToday).toFixed(2)} left
            </span>
          </div>
          
          {/* Progress Bar with Warnings */}
          <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden relative">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                student.spentToday / student.dailyAllowanceLimit > 0.85 
                  ? 'bg-rose-500' 
                  : student.spentToday / student.dailyAllowanceLimit > 0.6 
                  ? 'bg-orange-500' 
                  : 'bg-orange-500'
              }`}
              style={{ width: `${Math.min(100, (student.spentToday / student.dailyAllowanceLimit) * 100)}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 mt-2 font-mono">
            <span>0% (Saver)</span>
            <span>75% (Warn Threshold)</span>
            <span>100% (Daily Cap)</span>
          </div>
        </div>
      </div>

      {/* Main Panel splitting Menu on Left and Active Tokens / Cart Controls on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: Menu, Searches, Category sliders */}
        <div className="lg:col-span-2 space-y-5">
          
          {/* Filters & Search Header bar */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                <input 
                  type="text" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search breakfast, pasta rolls, beverages, avocado toast..." 
                  className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 placeholder-slate-400 font-sans"
                />
              </div>

              {/* Notification Quick Toggle */}
              <button 
                onClick={() => setShowNotificationDrawer(true)}
                className="relative bg-slate-50 hover:bg-slate-100 px-4 py-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-center gap-2 border border-slate-200 cursor-pointer transition-colors"
              >
                <Bell className="w-4 h-4 text-slate-600" />
                <span>Inbox</span>
                {unreadCount > 0 && (
                  <span className="w-2.5 h-2.5 bg-orange-500 rounded-full animate-ping absolute top-1 right-1" />
                )}
                {unreadCount > 0 && (
                  <span className="bg-orange-500 text-white font-mono text-[10px] px-1.5 py-0.2 rounded-full font-bold ml-1">
                    {unreadCount}
                  </span>
                )}
              </button>
            </div>

            {/* Category filter */}
            <div className="flex items-center space-x-2 overflow-x-auto pb-1 invisible-scrollbar">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mr-1">Category:</span>
              <button
                onClick={() => setSelectedCategory("All")}
                className={`text-xs px-3.5 py-1.5 rounded-full font-bold transition-all duration-150 whitespace-nowrap cursor-pointer ${
                  selectedCategory === "All" 
                    ? "bg-slate-900 text-white shadow-xs" 
                    : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-250"
                }`}
              >
                All Meals
              </button>
              {Object.values(CanteenCategory).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-xs px-3.5 py-1.5 rounded-full font-bold transition-all duration-150 whitespace-nowrap cursor-pointer ${
                    selectedCategory === cat 
                      ? "bg-orange-550 bg-orange-500 text-white shadow-xs"
                      : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-250"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Dietary Tags filters */}
            <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-150">
              <div className="flex items-center gap-1 mr-1">
                <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Dietary:</span>
              </div>
              {Object.values(DietaryPreference).map((pref) => {
                const isSelected = selectedDietary.includes(pref);
                return (
                  <button
                    key={pref}
                    onClick={() => toggleDietaryFilter(pref)}
                    className={`text-[10px] md:text-xs px-3 py-1 rounded-full font-bold transition-all duration-200 flex items-center gap-1.5 cursor-pointer border ${
                      isSelected 
                        ? "bg-emerald-50 text-emerald-800 border-emerald-300 font-bold shadow-3xs" 
                        : "bg-slate-55 bg-slate-50 text-slate-500 hover:bg-slate-100 border-slate-200"
                    }`}
                  >
                    {pref}
                    {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />}
                  </button>
                );
              })}
              {selectedDietary.length > 0 && (
                <button
                  onClick={() => setSelectedDietary([])}
                  className="text-[10px] uppercase font-bold tracking-wider text-orange-600 hover:text-orange-700 underline border-none bg-transparent cursor-pointer ml-1"
                >
                  Clear Filters
                </button>
              )}
            </div>
          </div>

          {/* Menu Catalog Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredMenu.length > 0 ? (
              filteredMenu.map((dish) => {
                const quantityInCart = cart.find(i => i.menuItem.id === dish.id)?.quantity || 0;
                const isOutofStock = dish.availableQuantity <= 0;
                
                return (
                  <div 
                    key={dish.id}
                    id={`dish-card-${dish.id}`}
                    className={`rounded-3xl overflow-hidden border transition-all duration-300 flex flex-col justify-between shadow-xs hover:shadow-sm ${
                      dish.isPopular 
                        ? "bg-orange-50/40 border-orange-200 hover:border-orange-300" 
                        : "bg-white border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <div className="relative h-44 overflow-hidden bg-slate-200">
                      <img 
                        src={dish.imageUrl} 
                        alt={dish.name}
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      {/* Popular badges */}
                      {dish.isPopular && (
                        <span className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur-xs text-amber-400 text-xs px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                          <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          <span>Campus Fav</span>
                        </span>
                      )}
                      
                      {/* Price badge overlaid right */}
                      <span className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-xs text-slate-800 text-sm font-bold px-3 py-1 rounded-lg shadow-sm border border-slate-100 font-mono">
                        ₹{dish.price.toFixed(2)}
                      </span>
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-display font-bold text-slate-800 text-base line-clamp-1">{dish.name}</h4>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-500">
                            {dish.category}
                          </span>
                        </div>
                        <p className="text-slate-500 text-xs line-clamp-2 min-h-8">
                          {dish.description}
                        </p>
                      </div>

                      {/* Dietary Indicators */}
                      <div className="flex flex-wrap gap-1">
                        {dish.dietary.map(d => (
                          <span 
                            key={d} 
                            className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 font-medium"
                          >
                            {d}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                        {/* Quantity in stock */}
                        <span className={`text-[10px] font-mono font-medium ${isOutofStock ? "text-rose-500" : "text-slate-400"}`}>
                          {isOutofStock ? "Sold out" : `${dish.availableQuantity} Left today`}
                        </span>

                        {/* Add / Subtract actions */}
                        <div className="flex items-center gap-2">
                          {quantityInCart > 0 && (
                            <>
                              <button
                                onClick={() => removeFromCart(dish.id)}
                                className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center font-bold focus:outline-none"
                              >
                                <Minus className="w-4 h-4" />
                              </button>
                              <span className="font-semibold text-sm w-4 text-center font-mono">{quantityInCart}</span>
                            </>
                          )}
                          <button
                            onClick={() => addToCart(dish)}
                            disabled={isOutofStock || quantityInCart >= dish.availableQuantity}
                            className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 focus:outline-none transition-all ${
                              isOutofStock 
                                ? "bg-slate-100 text-slate-300 cursor-not-allowed" 
                                : "bg-slate-900 text-white hover:bg-slate-800"
                            }`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="bg-white p-12 text-center rounded-2xl border border-slate-100 col-span-2 space-y-2">
                <p className="text-slate-400 text-sm">No items found matching your filter criteria.</p>
                <button 
                  onClick={() => { setSelectedCategory("All"); setSelectedDietary([]); setSearchQuery(""); }}
                  className="text-xs text-blue-600 hover:underline border-none bg-transparent font-medium"
                >
                  Reset all filters
                </button>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Pre-Order Tokens Form & Shopping Cart */}
        <div className="space-y-6">
          
          {/* Ongoing Order Status Card: Live Token Tracker */}
          {ongoingOrder ? (
            <div className="bg-indigo-600 text-white p-6 rounded-3xl shadow-sm relative overflow-hidden space-y-4 border border-indigo-700">
              <div className="absolute top-0 right-0 p-8 w-24 h-24 bg-white/10 rounded-full blur-2xl" />
              
              <div className="flex justify-between items-start border-b border-indigo-500/30 pb-3">
                <div className="space-y-1">
                  <span className="text-[9px] uppercase font-mono tracking-widest text-indigo-200">Active Campus Token</span>
                  <p className="text-xl font-bold font-display tracking-tight text-white">{ongoingOrder.tokenNumber}</p>
                </div>
                
                {/* Visual state badge indicating order completion progress */}
                <div className="flex items-center space-x-1.5 bg-white/15 border border-white/10 px-2.5 py-1 rounded-full text-xs font-semibold">
                  {ongoingOrder.status === OrderStatus.QUEUED && <Clock className="w-3.5 h-3.5 text-slate-250 animate-pulse" />}
                  {ongoingOrder.status === OrderStatus.COOKING && <Flame className="w-3.5 h-3.5 text-orange-300 animate-bounce" />}
                  {ongoingOrder.status === OrderStatus.READY_FOR_PICKUP && <CheckCircle className="w-3.5 h-3.5 text-emerald-350" />}
                  <span className={`${
                    ongoingOrder.status === OrderStatus.READY_FOR_PICKUP ? 'text-emerald-350' : 'text-slate-200'
                  } uppercase text-[9px] tracking-wider font-mono`}>
                    {ongoingOrder.status}
                  </span>
                </div>
              </div>

              {/* QR Token representation display - dynamic indicator state */}
              <div className="bg-white p-3.5 rounded-2xl max-w-[170px] mx-auto shadow-sm">
                {renderMiniQR(ongoingOrder.id, ongoingOrder.status)}
                <p className="text-center text-[9px] text-slate-400 tracking-wider font-mono font-bold mt-1.5 uppercase">SCAN AT STATION</p>
              </div>

              <div className="space-y-2.5 border-t border-indigo-500/30 pt-3">
                <div className="flex justify-between text-xs text-indigo-150">
                  <span>Smart Station target:</span>
                  <span className="font-bold text-white font-mono bg-white/20 px-2.5 py-0.5 rounded-lg text-xs">{ongoingOrder.pickupStationId}</span>
                </div>
                
                {ongoingOrder.status === OrderStatus.READY_FOR_PICKUP && (
                  <div className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 p-2.5 rounded-lg text-xs space-y-1 mt-2">
                    <p className="font-bold flex items-center gap-1 text-emerald-200 animate-pulse">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" /> Ready for Pickup!
                    </p>
                    <p className="text-[11px] text-emerald-300/90 leading-tight">
                      Head to individual Smart Station <span className="underline font-bold text-white">{ongoingOrder.pickupStationId}</span>. The buzzer and Desk indicator lamp are glowing.
                    </p>
                  </div>
                )}
                
                <div className="text-xs text-slate-400 space-y-1">
                  <div className="font-semibold text-slate-300">Ordered Items:</div>
                  <div className="max-h-24 overflow-y-auto space-y-1 pr-1">
                    {ongoingOrder.items.map(item => (
                      <div key={item.id} className="flex justify-between text-[11px]">
                        <span className="truncate max-w-[180px]">{item.name} <span className="text-slate-400">x{item.quantity}</span></span>
                        <span>₹{(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-orange-50/40 border border-orange-100 p-5 rounded-3xl text-center space-y-3.5">
              <div className="mx-auto w-11 h-11 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center">
                <QrCode className="w-5.5 h-5.5" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-bold text-slate-800">No Active Pickup Token</p>
                <p className="text-xs text-slate-500 leading-normal max-w-xs mx-auto">
                  Select delicious items from the campus selection to generate your secure digital pickup coin.
                </p>
              </div>
            </div>
          )}

          {/* Cart Panel & Checkout pre-order form */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-5">
            <h3 className="font-display font-bold text-slate-800 text-base flex items-center justify-between border-b border-slate-150 pb-3">
              <span className="flex items-center gap-1.5">
                <ShoppingBag className="w-4 h-4 text-orange-500" /> Pre-Order Basket
              </span>
              {cart.length > 0 && (
                <button 
                  onClick={clearCart}
                  className="text-slate-400 hover:text-rose-500 text-xs flex items-center gap-0.5 border-none bg-transparent cursor-pointer transition-colors"
                >
                  <Trash2 className="w-3 h-3" /> Clear Cart
                </button>
              )}
            </h3>

            {cart.length > 0 ? (
              <div className="space-y-4">
                {/* Cart list items */}
                <div className="space-y-3 max-h-48 overflow-y-auto pr-1">
                  {cart.map((item) => (
                    <div key={item.menuItem.id} className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-slate-800 truncate">{item.menuItem.name}</p>
                        <p className="text-[10px] text-slate-400 font-mono">₹{item.menuItem.price.toFixed(2)} each</p>
                      </div>
                      
                      <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg p-0.5">
                        <button 
                          onClick={() => removeFromCart(item.menuItem.id)}
                          className="w-5 h-5 rounded hover:bg-slate-200 text-slate-500 flex items-center justify-center text-xs font-bold focus:outline-none cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-bold w-4 text-center font-mono">{item.quantity}</span>
                        <button 
                          onClick={() => addToCart(item.menuItem)}
                          disabled={item.quantity >= item.menuItem.availableQuantity}
                          className="w-5 h-5 rounded hover:bg-slate-200 text-slate-500 flex items-center justify-center text-xs font-bold focus:outline-none cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Token Configuration Inputs / Options */}
                <div className="space-y-3 pt-2 border-t border-slate-150">
                  {/* Select smart table station ID */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 font-mono uppercase tracking-wider">Target Cafeteria Smart Station</label>
                    <select
                      value={selectedStation}
                      onChange={(e) => setSelectedStation(e.target.value)}
                      className="w-full text-xs p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-orange-500 font-sans bg-slate-50 font-semibold cursor-pointer"
                    >
                      <option value="STATION-1">Table Station 1 (Zone Alpha)</option>
                      <option value="STATION-2">Table Station 2 (Zone Beta)</option>
                      <option value="STATION-3">Table Station 3 (Zone Gamma)</option>
                      <option value="STATION-4">Table Station 4 (Zone Delta)</option>
                    </select>
                  </div>

                  {/* Notes collapser */}
                  <div>
                    <button 
                      type="button"
                      onClick={() => setIsNotesExpanded(!isNotesExpanded)}
                      className="text-[11px] font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1.5 focus:outline-none cursor-pointer"
                    >
                      <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isNotesExpanded ? 'rotate-90' : ''}`} />
                      <span>{isNotesExpanded ? "Hide custom notes" : "Add custom notes for dining kitchen"}</span>
                    </button>
                    {isNotesExpanded && (
                      <textarea
                        value={specialNotes}
                        onChange={(e) => setSpecialNotes(e.target.value)}
                        placeholder="E.g., Allergen warning: severe peanut allergy. Make sauce mild."
                        rows={2}
                        maxLength={120}
                        className="w-full text-xs p-2.5 border border-slate-200 rounded-lg focus:outline-none mt-1.5 text-slate-705 bg-slate-50 focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
                      />
                    )}
                  </div>
                </div>

                {/* Cart Bill Details */}
                <div className="bg-slate-50 p-3.5 rounded-2xl text-xs space-y-1.5 border border-slate-200 font-mono">
                  <div className="flex justify-between text-slate-550">
                    <span>Subtotal:</span>
                    <span>₹{cartSubtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-550">
                    <span>Vat Tax (8%):</span>
                    <span>₹{cartTax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-slate-800 border-t border-slate-200 pt-2 pb-0.5">
                    <span>Total Bill:</span>
                    <span className="text-sm font-black text-slate-900">₹{cartTotal.toFixed(2)}</span>
                  </div>
                </div>

                {/* Allowance check warnings */}
                {isOverLimit && (
                  <div className="bg-amber-50 border border-amber-200 text-amber-805 p-3.5 rounded-2xl text-xs flex gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
                    <div>
                      <p className="font-bold">Daily Expenditure Limit Exceeded</p>
                      <p className="text-[11px] text-amber-700/90 leading-tight">
                        Remaining today: ₹{remainingAllowance.toFixed(2)}. Remove items to complete transaction.
                      </p>
                    </div>
                  </div>
                )}

                {isOverWallet && !isOverLimit && (
                  <div className="bg-rose-50 border border-rose-200 text-rose-808 p-3.5 rounded-2xl text-xs flex gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                    <div>
                      <p className="font-bold">Insufficient Account Funds</p>
                      <p className="text-[11px] text-rose-700/90 leading-tight">
                        Wallet Balance: ₹{student.walletBalance.toFixed(2)}. Please click 'Refill Balance' above to proceed.
                      </p>
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleCheckout}
                  disabled={isOverLimit}
                  className={`w-full py-3 rounded-2xl font-bold font-display text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all focus:outline-none cursor-pointer ${
                    isOverLimit
                      ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                      : isOverWallet
                      ? "bg-orange-500 text-white hover:bg-orange-600 shadow-sm"
                      : "bg-orange-500 text-white hover:bg-orange-600 shadow-sm"
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isOverWallet && !isOverLimit ? "Add Funds & Checkout" : "Pre-Order & Deduct Wallet"}</span>
                </button>
              </div>
            ) : (
              <div className="text-center py-6 text-slate-400 text-xs">
                Your pre-order cart basket is empty.
              </div>
            )}
          </div>
        </div>

      </div>

      {/* History panel display */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
        <h3 className="font-display font-bold text-slate-800 text-base border-b border-slate-100 pb-3 mb-4">
          Personal Order & Billing History
        </h3>
        
        {activeStudentOrders.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-mono bg-slate-50/50">
                  <th className="p-3">TOKEN</th>
                  <th className="p-3">DATE/TIME</th>
                  <th className="p-3">MEALS IN ORDER</th>
                  <th className="p-3">DESTINATION STATION</th>
                  <th className="p-3">TOTAL CHARGE</th>
                  <th className="p-3">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activeStudentOrders.map((historyOrder) => (
                  <tr key={historyOrder.id} className="hover:bg-slate-50/55 transition-colors">
                    <td className="p-3 font-semibold font-mono text-slate-950">{historyOrder.tokenNumber}</td>
                    <td className="p-3 text-slate-500">
                      {new Date(historyOrder.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}{" "}
                      {new Date(historyOrder.timestamp).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="p-3 max-w-[200px] truncate">
                      {historyOrder.items.map(item => `${item.name} (x${item.quantity})`).join(", ")}
                    </td>
                    <td className="p-3 font-mono text-slate-600">{historyOrder.pickupStationId}</td>
                    <td className="p-3 font-semibold text-slate-900 font-mono">₹{historyOrder.total.toFixed(2)}</td>
                    <td className="p-3">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        historyOrder.status === OrderStatus.PICKED_UP 
                          ? "bg-emerald-50 text-emerald-700" 
                          : historyOrder.status === OrderStatus.QUEUED
                          ? "bg-slate-100 text-slate-600"
                          : historyOrder.status === OrderStatus.COOKING
                          ? "bg-amber-50 text-amber-700"
                          : historyOrder.status === OrderStatus.READY_FOR_PICKUP
                          ? "bg-blue-50 text-blue-700 animate-pulse border border-blue-200"
                          : "bg-rose-50 text-rose-700"
                      }`}>
                        {historyOrder.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-slate-400 text-xs py-4 text-center">No orders documented in this session history.</p>
        )}
      </div>

      {/* WALLET REFILL MODAL */}
      <AnimatePresence>
        {showWalletRefill && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-100 space-y-4"
            >
              <h4 className="font-display font-extrabold text-slate-800 text-lg flex items-center gap-1.5">
                <Wallet className="w-5 h-5 text-blue-600" /> Refill Canteen balance
              </h4>
              <p className="text-slate-500 text-xs leading-normal">
                Refills are securely charged to your registered credit, visa/debit card, or direct university billing account.
              </p>

              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-2">
                  {["100", "250", "500"].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setRefillAmount(amt)}
                      className={`py-2 text-xs font-mono font-bold border rounded-lg transition-colors focus:outline-none ${
                        refillAmount === amt 
                          ? "bg-blue-600 text-white border-blue-600" 
                          : "bg-slate-50 hover:bg-slate-100 text-slate-705 border-slate-200"
                      }`}
                    >
                      +₹{amt}
                    </button>
                  ))}
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Custom Amount (₹)</label>
                  <input
                    type="number"
                    value={refillAmount}
                    onChange={(e) => setRefillAmount(e.target.value)}
                    min="1"
                    max="5000"
                    placeholder="Enter amount"
                    className="w-full text-sm p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                <div className="flex gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowWalletRefill(false)}
                    className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-600 py-2 rounded-lg text-xs font-bold transition-colors focus:outline-none"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const value = parseFloat(refillAmount);
                      if (!isNaN(value) && value > 0) {
                        onAddFunds(value);
                        setShowWalletRefill(false);
                      }
                    }}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg text-xs font-bold transition-colors shadow-sm focus:outline-none"
                  >
                    Confirm & Top-up
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* NOTIFICATIONS MODAL (SLIDE IN INSPIRED DRAWER) */}
      <AnimatePresence>
        {showNotificationDrawer && (
          <div className="fixed inset-0 bg-slate-900/45 backdrop-blur-xs flex justify-end z-50">
            <motion.div 
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.25 }}
              className="bg-white w-full max-w-sm h-full shadow-2xl p-6 flex flex-col justify-between"
            >
              <div className="space-y-4 overflow-y-auto">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-1.5">
                    <Bell className="w-5 h-5 text-blue-600" />
                    <h3 className="font-display font-bold text-slate-800 text-lg">Inbox Alerts</h3>
                  </div>
                  <button 
                    onClick={() => setShowNotificationDrawer(false)}
                    className="text-xs uppercase font-bold text-slate-400 hover:text-slate-600 focus:outline-none bg-transparent border-none"
                  >
                    Close
                  </button>
                </div>

                {notifications.length > 0 && (
                  <div className="flex justify-end">
                    <button 
                      onClick={onClearNotifications}
                      className="text-[10px] text-slate-400 font-semibold hover:text-rose-500 bg-transparent border-none"
                    >
                      Dismiss all
                    </button>
                  </div>
                )}

                <div className="space-y-2 max-h-[75vh] overflow-y-auto">
                  {notifications.length > 0 ? (
                    notifications.map((notif) => (
                      <div 
                        key={notif.id}
                        onClick={() => onMarkNotificationRead(notif.id)}
                        className={`p-3 rounded-xl text-xs space-y-1 cursor-pointer transition-all border ${
                          notif.isRead 
                            ? "bg-slate-50 border-slate-100 text-slate-500 opacity-80" 
                            : "bg-blue-50/50 border-blue-100 text-slate-800 font-semibold shadow-xs"
                        }`}
                      >
                        <div className="flex justify-between items-start">
                          <p className="font-bold">{notif.title}</p>
                          <span className="text-[9px] font-mono text-slate-400">
                            {new Date(notif.timestamp).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-slate-600 font-normal leading-normal">{notif.message}</p>
                      </div>
                    ))
                  ) : (
                    <div className="py-20 text-center text-slate-400 space-y-1">
                      <Bell className="w-8 h-8 text-slate-200 mx-auto" />
                      <p className="text-xs">Your canteen inbox is quiet right now.</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t border-slate-100 pt-3">
                <p className="text-center text-[10px] text-slate-400 font-mono">CAMPUS PRE-ORDER CENTRAL • VERSION 1.10</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
