/**
 * =========================================================================
 * SUB-COMPONENT: SmartStation.tsx (Individual simulated hardware table signal lights)
 * COURSE OUTCOME (CO) MAPPINGS IN THIS FILE:
 * - [CO1] Foundations: Simulating physical hardware limitations and light signals.
 * - [CO2] TS Engineering: Typing of scanner and status updates for secure authentication.
 * - [CO3] React Component Model: Props binding and controlled text scanner inputs.
 * - [CO4] State Architecture: Lifted pickup transaction completion.
 * - [CO5] Forms & Reliability: Input QR-verification, keyboard scanner mock simulation.
 * =========================================================================
 */

import React, { useState, useMemo } from "react";
import { Order, OrderStatus } from "../types";
import { 
  QrCode, 
  Tv, 
  Volume2, 
  VolumeX, 
  Check, 
  HelpCircle, 
  Cpu, 
  BellRing,
  Smartphone,
  ChevronDown,
  Sparkles,
  Search
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface SmartStationProps {
  orders: Order[];
  onCompletePickup: (orderId: string) => void;
}

export default function SmartStation({
  orders,
  onCompletePickup
}: SmartStationProps) {
  // [CO3]: Local hardware state parameters inside the simulated station micro-controller
  const [activeStationId, setActiveStationId] = useState<string>("STATION-1");
  const [isBuzzerMuted, setIsBuzzerMuted] = useState(false);
  const [scannedCode, setScannedCode] = useState("");
  const [scanResult, setScanResult] = useState<{ success: boolean; msg: string } | null>(null);

  // [CO4]: Derived State (Active pre-orders routed to this physical location - using student loop)
  const stationOrders = useMemo(() => {
    let result: Order[] = [];
    for (let i = 0; i < orders.length; i++) {
      const o = orders[i];
      if (o.pickupStationId === activeStationId) {
        if (o.status !== OrderStatus.PICKED_UP && o.status !== OrderStatus.CANCELLED) {
          result.push(o);
        }
      }
    }
    return result;
  }, [orders, activeStationId]);

  // [CO1]: Declarative light rendering pipeline based on live state variables
  const stationStatus = useMemo(() => {
    let hasReady = false;
    let hasCooking = false;
    let hasQueued = false;

    for (let i = 0; i < stationOrders.length; i++) {
      const status = stationOrders[i].status;
      if (status === OrderStatus.READY_FOR_PICKUP) {
        hasReady = true;
      } else if (status === OrderStatus.COOKING) {
        hasCooking = true;
      } else if (status === OrderStatus.QUEUED) {
        hasQueued = true;
      }
    }

    if (hasReady) {
      return "READY";
    }
    if (hasCooking) {
      return "COOKING";
    }
    if (hasQueued) {
      return "QUEUED";
    }
    return "IDLE";
  }, [stationOrders]);

  const activeReadyOrder = useMemo(() => {
    for (let i = 0; i < stationOrders.length; i++) {
      if (stationOrders[i].status === OrderStatus.READY_FOR_PICKUP) {
        return stationOrders[i];
      }
    }
    return undefined;
  }, [stationOrders]);

  // [CO5]: Form handling simulated QR submittal with error surface alerts
  const handleScanToken = (tokenNumber: string) => {
    if (!tokenNumber) {
      return;
    }
    
    // Find matching order in active status for this station using standard student loop
    let match: Order | undefined = undefined;
    for (let i = 0; i < orders.length; i++) {
      if (orders[i].tokenNumber.toUpperCase() === tokenNumber.toUpperCase().trim()) {
        match = orders[i];
        break; // found match
      }
    }

    if (!match) {
      setScanResult({ success: false, msg: "Invalid token. Refused." });
      return;
    }

    if (match.pickupStationId !== activeStationId) {
      setScanResult({ 
        success: false, 
        msg: `Token ${match.tokenNumber} routed to physical ${match.pickupStationId}. Scan failed here.` 
      });
      return;
    }

    if (match.status === OrderStatus.PICKED_UP) {
      setScanResult({ success: false, msg: "Meal already retrieved for this token." });
      return;
    }

    if (match.status !== OrderStatus.READY_FOR_PICKUP) {
      setScanResult({ 
        success: false, 
        msg: `Pre-order has status '${match.status}'. Mark as 'Ready' in chef queue first.` 
      });
      return;
    }

    // Success! Calculate quantity in total boxes
    let totalBoxes = 0;
    for (let j = 0; j < match.items.length; j++) {
      totalBoxes = totalBoxes + match.items[j].quantity;
    }

    onCompletePickup(match.id);
    setScanResult({ success: true, msg: `Token verified! Dispensing ${totalBoxes} meal box(es).` });
    setScannedCode("");
    
    // Auto clear victory banner after 4 seconds
    setTimeout(() => {
      setScanResult(null);
    }, 4000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* COLUMN 1 & 2: Physically Simulated Smart Canteen Station Hardware */}
      <div className="lg:col-span-2 space-y-5">
        
        {/* Table/Station Selector Tabs */}
        <div className="bg-slate-100 p-1 rounded-xl flex gap-1 border border-slate-200">
          {["STATION-1", "STATION-2", "STATION-3", "STATION-4"].map((stationId, index) => {
            const hasReady = orders.some(o => o.pickupStationId === stationId && o.status === OrderStatus.READY_FOR_PICKUP);
            const hasCooking = orders.some(o => o.pickupStationId === stationId && o.status === OrderStatus.COOKING);
            
            return (
              <button
                key={stationId}
                onClick={() => { setActiveStationId(stationId); setScanResult(null); }}
                className={`flex-1 py-1.5 text-xs font-extrabold rounded-lg transition-all flex items-center justify-center gap-1.5 focus:outline-none cursor-pointer ${
                  activeStationId === stationId 
                    ? "bg-slate-900 text-white shadow-sm font-black" 
                    : "text-slate-600 hover:text-slate-900 bg-transparent hover:bg-white"
                }`}
              >
                <span>Desk {index + 1}</span>
                {hasReady ? (
                  <span className="w-2.5 h-2.5 rounded-full bg-orange-500 animate-ping shrink-0" />
                ) : hasCooking ? (
                  <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                ) : null}
              </button>
            );
          })}
        </div>

        {/* Industrial Device Housing Mount */}
        <div className="bg-slate-950 text-slate-200 rounded-3xl p-6 border-8 border-slate-800 shadow-xl relative overflow-hidden space-y-6">
          {/* Header indicator bar */}
          <div className="flex justify-between items-center border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2">
              <Cpu className="text-blue-500 w-5 h-5 shrink-0" />
              <div>
                <p className="text-[10px] font-mono tracking-wider uppercase text-slate-500">INDIVIDUAL DIGITAL BEACON</p>
                <h4 className="text-sm font-black font-display text-white tracking-wide">{activeStationId} HARNESS</h4>
              </div>
            </div>
            
            <span className="text-[10px] font-mono bg-slate-900 text-slate-400 px-2.5 py-1 rounded border border-slate-800">
              STATUS: ONLINE
            </span>
          </div>

          {/* Central Physical LED Glow Bulb and Buzzer Alarms */}
          <div className="text-center py-6 space-y-6">
            
            <div className="relative inline-block">
              {/* Outer light glow haloes based on state */}
              {stationStatus === "READY" && (
                <>
                  <div className="absolute inset-0 bg-rose-500 rounded-full scale-150 blur-xl opacity-40 animate-ping" />
                  <div className="absolute inset-0 bg-emerald-500 rounded-full scale-140 blur-lg opacity-30" />
                </>
              )}
              {stationStatus === "COOKING" && (
                <div className="absolute inset-0 bg-blue-500 rounded-full scale-125 blur-lg opacity-40 animate-pulse" />
              )}
              {stationStatus === "QUEUED" && (
                <div className="absolute inset-0 bg-slate-500/30 rounded-full scale-110 blur-md opacity-25" />
              )}

              {/* The main solid glowing hardware lens bulb */}
              <div className={`w-32 h-32 rounded-full mx-auto border-4 border-slate-900 flex flex-col items-center justify-center transition-all-300 ${
                stationStatus === "READY" 
                  ? "bg-rose-500 text-white shadow-xl shadow-rose-500/20" 
                  : stationStatus === "COOKING" 
                  ? "bg-blue-600 text-white shadow-md shadow-blue-500/20"
                  : stationStatus === "QUEUED"
                  ? "bg-slate-800 text-slate-300"
                  : "bg-slate-900 text-slate-700"
              }`}>
                {stationStatus === "READY" ? (
                  <BellRing className="w-10 h-10 animate-bounce" />
                ) : stationStatus === "COOKING" ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                  >
                    <Cpu className="w-10 h-10" />
                  </motion.div>
                ) : (
                  <QrCode className="w-10 h-10" />
                )}
              </div>
            </div>

            {/* LED Label and active details */}
            <div className="space-y-1">
              <p className="text-xs font-mono uppercase tracking-widest text-slate-500">Visual Signal Light</p>
              <h3 className="text-2xl font-black font-display tracking-tight text-white">
                {stationStatus === "READY" && "🔴 SIGNAL RED: MEAL IN PASS"}
                {stationStatus === "COOKING" && "🔷 SIGNAL BLUE: COOKING"}
                {stationStatus === "QUEUED" && "⚪ SIGNAL GREY: QUEUED"}
                {stationStatus === "IDLE" && "🟢 IDLE: VACANT FOR DINING"}
              </h3>
              
              {activeReadyOrder && (
                <div className="max-w-md mx-auto pt-4 space-y-2">
                  <div className="bg-rose-500/10 border border-rose-500/15 p-3 rounded-lg text-rose-300 text-xs">
                    <p className="font-bold">Meal Ready for Student Token: {activeReadyOrder.tokenNumber}</p>
                    <p className="text-[11px] text-rose-400 mt-1">
                      {activeReadyOrder.studentName} ({activeReadyOrder.studentRollNumber}) • Scan the token QR code to unlock high speed dispenser bins.
                    </p>
                  </div>
                  {!isBuzzerMuted && (
                    <div className="text-[10px] text-amber-500 animate-pulse font-mono flex items-center justify-center gap-1">
                      🔊 Virtual hardware buzzer pulsing: BEEP... BEEP... BEEP
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Device Controls Footer */}
          <div className="border-t border-slate-800 pt-4 flex justify-between items-center text-xs text-slate-500">
            <div className="flex items-center gap-1.5">
              <span>Buzzer Volume:</span>
              <button
                onClick={() => setIsBuzzerMuted(!isBuzzerMuted)}
                className={`bg-slate-900 border border-slate-800 px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 transition-colors ${
                  isBuzzerMuted ? "text-slate-600" : "text-amber-500"
                }`}
              >
                {isBuzzerMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                <span>{isBuzzerMuted ? "Muted" : "Active Alarm"}</span>
              </button>
            </div>
            
            <p className="font-mono text-[9px] text-slate-600">FIRMWARE: V2.14-A</p>
          </div>
        </div>

      </div>

      {/* COLUMN 3: QR Token Reader Simulator */}
      <div className="space-y-5">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5">
          <div className="border-b border-slate-150 pb-3">
            <h3 className="font-display font-bold text-slate-800 text-base flex items-center gap-1.5">
              <QrCode className="w-4.5 h-4.5 text-orange-500" /> Virtual QR Sensor
            </h3>
            <p className="text-[11px] text-slate-450 font-bold">Scan student pre-orders at table</p>
          </div>

          {/* Quick scan items helpful aid */}
          <div className="space-y-2.5">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
              Scan Help: Tokens at this table
            </p>
            {stationOrders.length > 0 ? (
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {stationOrders.map(o => (
                  <button
                    key={o.id}
                    onClick={() => { setScannedCode(o.tokenNumber); handleScanToken(o.tokenNumber); }}
                    className={`w-full text-left p-2.5 rounded-xl text-xs flex justify-between items-center transition-all duration-150 border cursor-pointer ${
                      o.status === OrderStatus.READY_FOR_PICKUP 
                        ? "bg-orange-50/40 border-orange-200 hover:bg-orange-50" 
                        : "bg-slate-50 border-slate-200 hover:bg-slate-100/70"
                    }`}
                  >
                    <div>
                      <p className="font-mono font-bold text-slate-800">{o.tokenNumber}</p>
                      <p className="text-[9px] text-slate-400 font-bold truncate max-w-[140px] uppercase font-mono mt-0.5">{o.studentName}</p>
                    </div>
                    <span className={`text-[9px] px-2.5 py-0.5 rounded-full font-bold uppercase transition-colors ${
                      o.status === OrderStatus.READY_FOR_PICKUP ? "bg-orange-500 text-white" : "bg-slate-200 text-slate-600"
                    }`}>
                      {o.status === OrderStatus.READY_FOR_PICKUP ? "TAP TO SCAN" : o.status}
                    </span>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-slate-400 text-[11px] py-3.5 px-3 bg-slate-50 border border-slate-200 rounded-xl text-center leading-relaxed">
                No orders are routed here. Ready tokens will slide in when the chef flags them.
              </p>
            )}
          </div>

          {/* Scanning interface text input */}
          <div className="space-y-3.5 pt-3.5 border-t border-slate-150">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Interactive Scan Input</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={scannedCode}
                  onChange={(e) => setScannedCode(e.target.value)}
                  placeholder="E.g., TC-207"
                  className="flex-1 text-sm p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-mono text-center uppercase font-bold text-slate-800 bg-slate-50"
                />
                <button
                  type="button"
                  onClick={() => handleScanToken(scannedCode)}
                  className="bg-slate-900 text-white hover:bg-slate-800 px-4 py-2.5 rounded-xl text-xs font-bold font-mono focus:outline-none shrink-0 cursor-pointer transition-colors"
                >
                  Verify
                </button>
              </div>
            </div>

            {/* Scan results banners */}
            {scanResult && (
              <div className={`p-4 rounded-xl text-xs leading-relaxed border ${
                scanResult.success 
                  ? "bg-emerald-50 border-emerald-250 text-emerald-800 font-bold" 
                  : "bg-rose-50 border-rose-250 text-rose-800 font-bold"
              }`}>
                <p className="font-bold">{scanResult.success ? "✅ SCAN APPROVED" : "❌ DISPENSER DENIED"}</p>
                <p className="text-[11px] font-medium mt-1 text-slate-700 leading-normal">{scanResult.msg}</p>
              </div>
            )}
          </div>

        </div>
      </div>

    </div>
  );
}
