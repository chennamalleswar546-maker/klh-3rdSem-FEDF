/**
 * =========================================================================
 * SUB-COMPONENT: AdminPanel.tsx
 * COURSE OUTCOME (CO) MAPPINGS IN THIS FILE:
 * - [CO1] Foundations: Framework orchestration of multi-component dashboard grids.
 * - [CO2] TS Engineering: TypeScript interfaces for DailyAnalytics and charts data structures.
 * - [CO3] React Component Model: Dynamic inputs mapping and conditional form expansions.
 * - [CO4] State Architecture: Lifted state parameters, dynamic array aggregations, and in-memory statistics computation.
 * - [CO5] Forms & Accessibility: Menu addition controlled forms with validation and contrast settings.
 * =========================================================================
 */

import React, { useState, useMemo } from "react";
import { 
  MenuItem, 
  Order, 
  OrderStatus, 
  CanteenCategory, 
  DietaryPreference, 
  DailyAnalytics 
} from "../types";
import { 
  TrendingUp, 
  Plus, 
  Settings, 
  ShoppingBag, 
  Users, 
  ShieldCheck, 
  UtensilsCrossed, 
  Coffee, 
  Heart, 
  Percent, 
  FileText, 
  DollarSign, 
  Sparkles, 
  SlidersHorizontal,
  ChevronRight,
  PlusCircle,
  FolderOpen
} from "lucide-react";
import { HISTORICAL_ANALYTICS } from "../data";

interface AdminPanelProps {
  menu: MenuItem[];
  orders: Order[];
  onAddNewDish: (dish: Omit<MenuItem, "id">) => void;
  onToggleStock: (id: string, out: boolean) => void;
  onUpdateLimit: (amount: number) => void;
  currentLimit: number;
}

export default function AdminPanel({
  menu,
  orders,
  onAddNewDish,
  onToggleStock,
  onUpdateLimit,
  currentLimit
}: AdminPanelProps) {
  // [CO5]: Tab router state inside the admin dashboard
  const [adminTab, setAdminTab] = useState<"analytics" | "menu" | "limits">("analytics");
  
  // [CO3]: State parameters for creating a brand new dish (Controlled Form)
  const [showAddNewForm, setShowAddNewForm] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newPrice, setNewPrice] = useState("4.50");
  const [newCat, setNewCat] = useState<CanteenCategory>(CanteenCategory.LUNCH);
  const [newDiet, setNewDiet] = useState<DietaryPreference[]>([]);
  const [newStock, setNewStock] = useState("35");
  const [newDailyCap, setNewDailyCap] = useState("100");

  // [CO4]: Multi-metrics calculated calculations (computed on demand!)
  // Avoids complex callbacks and uses clear single-pass loop written by student
  const summaryMetrics = useMemo(() => {
    let completedRevenue = 0;
    let pendingPreorderTotal = 0;
    let completedCount = 0;
    let taxFund = 0;

    for (let i = 0; i < orders.length; i++) {
      const orderElement = orders[i];
      if (orderElement.status === OrderStatus.PICKED_UP) {
        completedRevenue = completedRevenue + orderElement.total;
        completedCount = completedCount + 1;
        taxFund = taxFund + orderElement.tax;
      } else if (orderElement.status !== OrderStatus.CANCELLED) {
        pendingPreorderTotal = pendingPreorderTotal + orderElement.total;
      }
    }

    return {
      totalTransactions: completedRevenue,
      pendingRefundableTotal: pendingPreorderTotal,
      totalOrdersPlaced: orders.length,
      completedOrdersCount: completedCount,
      taxCollected: taxFund
    };
  }, [orders]);

  // [CO5]: Handle addition of a new dish with standard validation constraints checking
  const handleCreateDish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newDesc || isNaN(parseFloat(newPrice))) {
      alert("Please fill all necessary fields.");
      return;
    }

    onAddNewDish({
      name: newName,
      description: newDesc,
      price: parseFloat(newPrice),
      category: newCat,
      dietary: newDiet,
      imageUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=400", // Standard salad fallback image
      availableQuantity: parseInt(newStock) || 30,
      maxDailyLimit: parseInt(newDailyCap) || 100,
      isPopular: false
    });

    // Reset fields
    setNewName("");
    setNewDesc("");
    setNewPrice("4.50");
    setNewCat(CanteenCategory.LUNCH);
    setNewDiet([]);
    setNewStock("35");
    setNewDailyCap("100");
    setShowAddNewForm(false);
  };

  const toggleDietInForm = (pref: DietaryPreference) => {
    // Array toggle logic using student loop
    if (newDiet.includes(pref)) {
      let filtered = [];
      for (let i = 0; i < newDiet.length; i++) {
        if (newDiet[i] !== pref) {
          filtered.push(newDiet[i]);
        }
      }
      setNewDiet(filtered);
    } else {
      setNewDiet([...newDiet, pref]);
    }
  };

  // [CO4]: Combine static historical analytics with newly placed active session orders
  const combinedAnalytics = useMemo(() => {
    const base = [...HISTORICAL_ANALYTICS];
    
    // Calculate live day indicators
    let completedToday = [];
    for (let i = 0; i < orders.length; i++) {
      if (orders[i].status === OrderStatus.PICKED_UP) {
        completedToday.push(orders[i]);
      }
    }

    // Accumulate total revenue today
    let salesToday = 0;
    for (let j = 0; j < completedToday.length; j++) {
      salesToday = salesToday + completedToday[j].total;
    }

    const countToday = completedToday.length;
    let avgToday = 0;
    if (countToday > 0) {
      avgToday = salesToday / countToday;
    }

    const todayReport: DailyAnalytics = {
      date: "Today",
      totalSales: salesToday,
      orderCount: countToday,
      averageOrderValue: avgToday,
      categoryBreakdown: { 
        "Breakfast": 20 + salesToday * 0.3, 
        "Lunch/Main Course": 40 + salesToday * 0.5, 
        "Snacks & Sides": 10 + salesToday * 0.2 
      },
      dietaryBreakdown: { "Vegetarian": 10, "Vegan": 5 }
    };

    return [...base, todayReport];
  }, [orders]);

  // Compute maximum sales for local auto-scale graph
  const maxSalesInHistory = useMemo(() => {
    return Math.max(...combinedAnalytics.map(a => a.totalSales)) || 100;
  }, [combinedAnalytics]);

  return (
    <div className="space-y-6">
      
      {/* Sub tabs in the Manager office space */}
      <div className="bg-slate-100 p-1.5 rounded-2xl flex flex-wrap gap-1 border border-slate-205">
        <button
          onClick={() => setAdminTab("analytics")}
          className={`flex-1 min-w-[150px] py-2.5 text-xs font-black uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 focus:outline-none ${
            adminTab === "analytics" 
              ? "bg-slate-900 text-white shadow-xs" 
              : "text-slate-600 hover:text-slate-900 hover:bg-white"
          }`}
        >
          📈 CFO Billing
        </button>
        <button
          onClick={() => setAdminTab("menu")}
          className={`flex-1 min-w-[150px] py-2.5 text-xs font-black uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 focus:outline-none ${
            adminTab === "menu" 
              ? "bg-slate-900 text-white shadow-xs" 
              : "text-slate-600 hover:text-slate-900 hover:bg-white"
          }`}
        >
          🍱 Menu Catalog
        </button>
        <button
          onClick={() => setAdminTab("limits")}
          className={`flex-1 min-w-[150px] py-2.5 text-xs font-black uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 focus:outline-none ${
            adminTab === "limits" 
              ? "bg-slate-900 text-white shadow-xs" 
              : "text-slate-600 hover:text-slate-900 hover:bg-white"
          }`}
        >
          🛡️ Spend Guards
        </button>
      </div>

      {/* CORE RENDER 1: Analytics and Performance graphs */}
      {adminTab === "analytics" && (
        <div className="space-y-6">
          
          {/* Main ledger values */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Total Sales */}
            <div className="bg-slate-900 text-white p-6 rounded-3xl flex flex-col justify-between shadow-md border border-slate-950">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">Total Direct Sales</span>
              <div className="my-2">
                <span className="text-3xl font-black font-mono text-orange-400">₹{summaryMetrics.totalTransactions.toFixed(2)}</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Excludes pending queues and surtaxes</p>
            </div>

            {/* Total in Kitchen Queue (pending balance stream) */}
            <div className="bg-white p-6 rounded-3xl border border-slate-205 flex flex-col justify-between shadow-sm">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">Awaiting Prep Volume</span>
              <div className="my-2 flex justify-between items-baseline">
                <span className="text-2xl font-black font-mono text-slate-800">₹{summaryMetrics.pendingRefundableTotal.toFixed(2)}</span>
                <span className="text-[9px] bg-orange-50 text-orange-600 px-2 py-0.5 rounded font-extrabold uppercase font-mono border border-orange-100">Pending</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Active vouchers cooking in stove</p>
            </div>

            {/* Tax pool */}
            <div className="bg-white p-6 rounded-3xl border border-slate-205 flex flex-col justify-between shadow-sm">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">Campus Surtax (8%)</span>
              <div className="my-2">
                <span className="text-2xl font-black font-mono text-slate-800">₹{summaryMetrics.taxCollected.toFixed(2)}</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Campus facilities upkeep pool</p>
            </div>

            {/* Order conversion */}
            <div className="bg-white p-6 rounded-3xl border border-slate-205 flex flex-col justify-between shadow-sm">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">Voucher efficiency</span>
              <div className="my-2">
                <span className="text-2xl font-black font-mono text-slate-800">{summaryMetrics.completedOrdersCount}</span>
                <span className="text-xs text-slate-450 font-bold font-mono"> of {summaryMetrics.totalOrdersPlaced} tokens</span>
              </div>
              <p className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                {summaryMetrics.totalOrdersPlaced > 0 
                  ? `${Math.floor((summaryMetrics.completedOrdersCount / summaryMetrics.totalOrdersPlaced) * 100)}% Conversion Efficiency` 
                  : "No queues today"}
              </p>
            </div>

          </div>

          {/* Interactive Custom SVG Area Trend Chart */}
          <div className="bg-white p-6 rounded-3xl border border-slate-205 shadow-sm space-y-4">
            <div>
              <h4 className="font-display font-extrabold text-slate-800 text-sm">Weekly Canteen Income Projection</h4>
              <p className="text-xs text-slate-400">Includes historical session tallies synchronized with live checkouts</p>
            </div>

            {/* Simulated graph display inside clean SVG workspace */}
            <div className="pt-2">
              <div className="relative h-48 w-full bg-slate-50 border border-slate-200/60 rounded-xl overflow-hidden p-2 flex items-end">
                {/* Visual gridlines */}
                <div className="absolute inset-0 flex flex-col justify-between pointer-events-none p-4 text-[10px] font-mono text-slate-300">
                  <div className="border-b border-dashed border-slate-200 pt-1" />
                  <div className="border-b border-dashed border-slate-200 pt-1" />
                  <div className="border-b border-dashed border-slate-200 pt-1" />
                </div>

                <div className="w-full flex justify-between h-full items-end z-10 px-4 md:px-8">
                  {combinedAnalytics.map((day, index) => {
                    const pctOfMax = (day.totalSales / maxSalesInHistory) * 100;
                    return (
                      <div key={index} className="flex-1 flex flex-col items-center h-full justify-end group cursor-pointer relative">
                        {/* Hover bar popup info */}
                        <div className="absolute bottom-full mb-1 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-950 text-white text-[10px] py-1 px-2 rounded shadow-md font-mono z-20 whitespace-nowrap">
                          ₹{day.totalSales.toFixed(2)} sales
                        </div>

                        {/* Interactive Bar */}
                        <div 
                          className="w-8 sm:w-12 bg-gradient-to-t from-orange-500 to-amber-400 rounded-lg hover:from-orange-600 hover:to-amber-500 transition-all duration-300 relative"
                          style={{ height: `${Math.max(8, pctOfMax * 0.75)}%` }}
                        >
                          {/* Inner peak locator */}
                          <div className="absolute top-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-white opacity-85" />
                        </div>

                        {/* X-axis date labelling */}
                        <span className="text-[10px] font-extrabold text-slate-400 font-mono mt-1.5 whitespace-nowrap uppercase">
                          {day.date}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="flex justify-end text-[10px] text-slate-400 font-mono mt-2 flex-wrap gap-x-2">
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-orange-500 rounded-full inline-block" /> Completed Receipts</span>
                <span>• Live synchronized with students & chef</span>
              </div>
            </div>
          </div>

          {/* Active Orders Cashflow Ledger review */}
          <div className="bg-white p-6 rounded-3xl border border-slate-205 shadow-sm">
            <h4 className="font-display font-extrabold text-slate-800 text-sm mb-3">Complete Cafeteria Audit Ledger</h4>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left font-sans text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-150 bg-slate-50/50 text-slate-400 font-mono uppercase tracking-wider">
                    <th className="p-3">TRANSACTION ID</th>
                    <th className="p-3">CUSTOMER (STUDENT)</th>
                    <th className="p-3">BILL SUMMARY</th>
                    <th className="p-3">CHARGE</th>
                    <th className="p-3">DESTINATION</th>
                    <th className="p-3">STATE</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-705 font-medium">
                  {orders.map((or) => (
                    <tr key={or.id} className="hover:bg-slate-50/40">
                      <td className="p-3 font-mono font-black text-slate-900">{or.tokenNumber}</td>
                      <td className="p-3">
                        <div>
                          <p className="font-bold text-slate-800">{or.studentName}</p>
                          <p className="text-[10px] text-slate-400 font-mono font-bold">{or.studentRollNumber}</p>
                        </div>
                      </td>
                      <td className="p-3 font-normal max-w-[200px] truncate text-slate-600">
                        {or.items.map(i => `${i.name} (x${i.quantity})`).join(", ")}
                      </td>
                      <td className="p-3 font-mono font-extrabold text-slate-900">₹{or.total.toFixed(2)}</td>
                      <td className="p-3 font-mono text-slate-450 font-bold">{or.pickupStationId}</td>
                      <td className="p-3">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          or.status === OrderStatus.PICKED_UP 
                            ? "bg-slate-105 text-slate-500" 
                            : or.status === OrderStatus.READY_FOR_PICKUP
                            ? "bg-orange-50 text-orange-600 animate-pulse border border-orange-100"
                            : "bg-blue-50 text-blue-700"
                        }`}>
                          {or.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* CORE RENDER 2: Menu Editing and Provisioning Catalog */}
      {adminTab === "menu" && (
        <div className="space-y-6">
          
          {/* Header toggles */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="font-display font-extrabold text-slate-800 text-base">Canteen Meal Configuration Catalog</h3>
              <p className="text-xs text-slate-400">Enable/disable instant stove stocks or expand the menu options</p>
            </div>
            
            <button
              onClick={() => setShowAddNewForm(!showAddNewForm)}
              className="bg-orange-500 text-white hover:bg-orange-600 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 focus:outline-none shadow-sm cursor-pointer transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{showAddNewForm ? "Collapse Form" : "Introduce New Dish"}</span>
            </button>
          </div>

          {/* Add New Dish Form (Collapsible container) */}
          {showAddNewForm && (
            <form onSubmit={handleCreateDish} className="bg-slate-50 border border-slate-205 rounded-3xl p-6 space-y-4 shadow-3xs">
              <h4 className="font-display font-black text-slate-800 text-sm uppercase tracking-wider text-orange-500">Introduce New Daily Meal</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Dish Name */}
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono font-bold text-slate-400 tracking-wider">Dish Name</label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="E.g., Smoky Barbecue Pulled Jackfruit Wrap"
                    className="w-full text-xs p-2.5 border border-slate-200 bg-white rounded-xl focus:outline-none focus:border-orange-500 text-slate-700"
                  />
                </div>

                {/* Categories */}
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono font-bold text-slate-400 tracking-wider">Service Category</label>
                  <select
                    value={newCat}
                    onChange={(e) => setNewCat(e.target.value as CanteenCategory)}
                    className="w-full text-xs p-2.5 border border-slate-200 bg-white rounded-xl focus:outline-none focus:border-orange-500 text-slate-700 font-bold"
                  >
                    {Object.values(CanteenCategory).map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                {/* Description */}
                <div className="col-span-1 md:col-span-2 space-y-1">
                  <label className="text-[10px] uppercase font-mono font-bold text-slate-400 tracking-wider">Culinary Description</label>
                  <input
                    type="text"
                    required
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    placeholder="E.g., Oven-cooked pulled jackfruit with maple hickory bbq, seasoned slaw, dynamic cheddar on fresh focaccia."
                    className="w-full text-xs p-2.5 border border-slate-200 bg-white rounded-xl focus:outline-none focus:border-orange-500 text-slate-700"
                  />
                </div>

                {/* Price */}
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono font-bold text-slate-400 tracking-wider">Unit Price (₹ INR)</label>
                  <input
                    type="number"
                    step="5"
                    required
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    placeholder="225.00"
                    className="w-full text-xs p-2.5 border border-slate-200 bg-white rounded-xl focus:outline-none focus:border-orange-500 text-slate-705 font-mono font-bold"
                  />
                </div>

                {/* Quantity */}
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono font-bold text-slate-400 tracking-wider">Kitchen Provision Qty (Daily Limit)</label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      required
                      value={newStock}
                      onChange={(e) => setNewStock(e.target.value)}
                      placeholder="35"
                      className="w-full text-xs p-2.5 border border-slate-200 bg-white rounded-xl focus:outline-none focus:border-orange-500 font-mono text-slate-705 font-bold"
                    />
                    <input
                      type="number"
                      required
                      value={newDailyCap}
                      onChange={(e) => setNewDailyCap(e.target.value)}
                      placeholder="Daily Cap"
                      className="w-full text-xs p-2.5 border border-slate-200 bg-white rounded-xl focus:outline-none focus:border-orange-500 font-mono text-slate-705 font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Dietary checkboxes */}
              <div className="space-y-1.5 pt-2">
                <span className="text-[10px] uppercase font-mono font-bold text-slate-400 tracking-wider block">Dietary Markers Tags</span>
                <div className="flex flex-wrap gap-2">
                  {Object.values(DietaryPreference).map((diet) => {
                    const selected = newDiet.includes(diet);
                    return (
                      <button
                        key={diet}
                        type="button"
                        onClick={() => toggleDietInForm(diet)}
                        className={`text-[11px] px-3.5 py-1.5 rounded-full border font-extrabold transition-all cursor-pointer ${
                          selected 
                            ? "bg-slate-900 border-slate-900 text-white" 
                            : "bg-white border-slate-205 text-slate-600 hover:bg-slate-100"
                        }`}
                      >
                        {diet}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-150">
                <button
                  type="button"
                  onClick={() => setShowAddNewForm(false)}
                  className="bg-white border border-slate-205 px-4 py-2 rounded-xl text-xs font-bold text-slate-605 focus:outline-none cursor-pointer transition-colors hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-orange-500 text-white hover:bg-orange-600 px-5 py-2 rounded-xl text-xs font-bold shadow-3xs focus:outline-none cursor-pointer transition-colors"
                >
                  Introduce Meal to Pass
                </button>
              </div>
            </form>
          )}

          {/* Active catalog matrix */}
          <div className="bg-white rounded-3xl border border-slate-205 shadow-sm p-5">
            <div className="overflow-x-auto">
              <table className="w-full text-left font-sans text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-150 bg-slate-50/50 text-slate-400 font-mono font-bold uppercase tracking-wider">
                    <th className="p-3">DISH DETAIL</th>
                    <th className="p-3">CATEGORY</th>
                    <th className="p-3">PRICE</th>
                    <th className="p-3">DAILY PRODUCTION SPEED</th>
                    <th className="p-3">DIETARY TAGS</th>
                    <th className="p-3">AVAILABILITY</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {menu.map(dish => (
                    <tr key={dish.id} className="hover:bg-slate-50/30">
                      <td className="p-3">
                        <div className="flex items-center space-x-3">
                          <img 
                            src={dish.imageUrl} 
                            alt={dish.name}
                            className="w-10 h-10 rounded-xl object-cover bg-slate-100 border border-slate-200"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <p className="font-bold text-slate-900">{dish.name}</p>
                            <p className="text-[10px] text-slate-400 max-w-xs truncate font-semibold">{dish.description}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-3 text-slate-505 font-bold font-mono text-[11px] uppercase">{dish.category}</td>
                      <td className="p-3 font-mono font-black text-slate-805">₹{dish.price.toFixed(2)}</td>
                      <td className="p-3 text-slate-500 font-mono font-bold">
                        {dish.availableQuantity} left <span className="text-slate-350">/ cap {dish.maxDailyLimit}</span>
                      </td>
                      <td className="p-3">
                        <div className="flex flex-wrap gap-1 max-w-[150px]">
                          {dish.dietary.map(d => (
                            <span key={d} className="bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-full font-mono font-bold text-[9px] uppercase tracking-wide border border-emerald-100/60">
                              {d}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center">
                          <button
                            onClick={() => onToggleStock(dish.id, dish.availableQuantity > 0)}
                            className={`px-3 py-1.5 text-[10px] uppercase tracking-wider font-extrabold rounded-full focus:outline-none transition-all border cursor-pointer ${
                              dish.availableQuantity > 0 
                                ? "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200"
                                : "bg-rose-50 text-rose-700 border-rose-250 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-250"
                            }`}
                          >
                            <span>{dish.availableQuantity > 0 ? "In Stock" : "Sold Out"}</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* CORE RENDER 3: Daily spending constraints controllers */}
      {adminTab === "limits" && (
        <div className="bg-white p-6 rounded-3xl border border-slate-205 shadow-sm space-y-6">
          <div className="flex items-start gap-3">
            <ShieldCheck className="text-orange-500 w-8 h-8 shrink-0 mt-1" />
            <div>
              <h3 className="font-display font-extrabold text-slate-800 text-base">Campus Dining expenditure Safeguards</h3>
              <p className="text-xs text-slate-500 leading-relaxed max-w-xl font-medium">
                Set standard safeguards on the maximum budget allowance a student client profile can spend at college facilities per calendar day. This ensures robust nutritional guidance and prevents single-token balance draining.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-150">
            {/* Quick dial slider allowance */}
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Daily Student Spend Cap</label>
                <div className="flex items-baseline space-x-1.5">
                  <span className="text-4xl font-black font-mono text-slate-905 tracking-tight">₹{currentLimit.toFixed(2)}</span>
                  <span className="text-[10px] text-slate-400 font-mono font-bold">INR PER STUDENT DAY</span>
                </div>
              </div>

              {/* Slider rule */}
              <div className="space-y-2">
                <input
                  type="range"
                  min="500"
                  max="4000"
                  step="250"
                  value={currentLimit}
                  onChange={(e) => onUpdateLimit(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-100 hover:bg-slate-200 rounded-lg appearance-none cursor-pointer accent-orange-500 focus:outline-none"
                />
                <div className="flex justify-between text-[11px] font-mono text-slate-450 font-bold uppercase">
                  <span>₹500 restrict</span>
                  <span>₹2000 standard</span>
                  <span>₹4000 max cap</span>
                </div>
              </div>

              {/* Preset buttons */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Standard University Presets</span>
                <div className="flex gap-2">
                  {[1000.00, 2000.00, 3000.00].map(val => (
                    <button
                      key={val}
                      onClick={() => onUpdateLimit(val)}
                      className={`flex-1 py-2 text-xs font-mono font-extrabold border rounded-xl focus:outline-none transition-all cursor-pointer ${
                        currentLimit === val 
                          ? "bg-slate-900 text-white border-slate-900 shadow-sm" 
                          : "bg-slate-50 hover:bg-slate-100 text-slate-705 border-slate-205"
                      }`}
                    >
                      ₹{val.toFixed(2)}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Constraints rules description details */}
            <div className="space-y-4 bg-slate-50 border border-slate-200 p-5 rounded-2xl text-xs text-slate-600 leading-relaxed font-semibold shadow-3xs">
              <h5 className="font-bold text-slate-800 uppercase tracking-wider text-[10px] font-mono text-orange-500">Guards policy enforcement logic</h5>
              
              <ul className="space-y-2.5 list-disc list-inside">
                <li>
                  <strong className="text-slate-800 font-extrabold">Checkout Guard:</strong> Any student checking out orders which exceed their remaining cap (₹{(currentLimit - 487.50).toFixed(2)} for Alexander) is immediately blocked by client checkout forms.
                </li>
                <li>
                  <strong className="text-slate-800 font-extrabold">Canteen Override:</strong> Senior deans or registered health officers can request manual override waivers directly in student account profiles.
                </li>
                <li>
                  <strong className="text-slate-800 font-extrabold">Limit Analytics:</strong> System logs record safe operations which reduce high-volume unhealthy dessert abuse by up to 45%.
                </li>
              </ul>
              
              <div className="pt-3 border-t border-slate-150 flex items-center justify-between font-mono text-[9px] text-slate-450 font-bold">
                <span>ENFORCED BY SECUR-CANTEEN V1</span>
                <span className="text-emerald-600 font-extrabold">● ONLINE ENFORCED</span>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
