/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum DietaryPreference {
  VEGETARIAN = "Vegetarian",
  VEGAN = "Vegan",
  GLUTEN_FREE = "Gluten-Free",
  HALAL = "Halal",
  DAIRY_FREE = "Dairy-Free",
  NUT_FREE = "Nut-Free"
}

export enum CanteenCategory {
  BREAKFAST = "Breakfast",
  LUNCH = "Lunch/Main Course",
  SNACKS = "Snacks & Sides",
  BEVERAGES = "Beverages",
  DESSERTS = "Desserts"
}

export enum OrderStatus {
  QUEUED = "Queued",
  COOKING = "Preparing",
  READY_FOR_PICKUP = "Ready for Pickup",
  PICKED_UP = "Completed",
  CANCELLED = "Cancelled"
}

export enum OrderPriority {
  LOW = "Low",
  MEDIUM = "Medium",
  HIGH = "High",
  CRITICAL = "Critical"
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: CanteenCategory;
  dietary: DietaryPreference[];
  imageUrl: string;
  availableQuantity: number;
  maxDailyLimit: number;
  isPopular?: boolean;
}

export interface OrderItem {
  id: string; // matches MenuItem id
  name: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  tokenNumber: string; // Format: TC-1002
  studentId: string;
  studentName: string;
  studentRollNumber: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  total: number;
  status: OrderStatus;
  priority: OrderPriority;
  timestamp: string; // ISO String
  specialNotes?: string;
  pickupStationId: string; // simulated desk ID e.g., "STATION-4"
  readyAt?: string;
  completedAt?: string;
}

export interface StudentProfile {
  id: string;
  name: string;
  rollNumber: string;
  email: string;
  department: string;
  walletBalance: number;
  dailyAllowanceLimit: number; // Max budget per day e.g., $15.00
  spentToday: number; // Current daily spending
  defaultDietaryPreferences: DietaryPreference[];
  avatarUrl: string;
}

export interface CanteenNotification {
  id: string;
  title: string;
  message: string;
  type: "info" | "warning" | "success" | "alert";
  timestamp: string;
  isRead: boolean;
  orderId?: string;
}

export interface DailyAnalytics {
  date: string;
  totalSales: number;
  orderCount: number;
  averageOrderValue: number;
  categoryBreakdown: Record<string, number>;
  dietaryBreakdown: Record<string, number>;
}
